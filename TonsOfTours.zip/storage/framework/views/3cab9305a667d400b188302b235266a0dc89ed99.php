<section class="main-nav">
    
    <div class="row top-nav">
        <div class="container">
            <nav class="navbar">
                <div class="container-fluid">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="">
                                <i class="fas fa-heart"></i> WishList
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('cart')); ?>">
                                <i class="fas fa-shopping-cart"></i> Cart
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fas fa-question-circle"></i> Help
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fas fa-user-circle"></i> Login
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fas fa-user-plus"></i> Sign Up
                            </a>
                        </li>
                    </ul>


                </div>
            </nav>
        </div>
    </div>
    
    
    <div class="row main-navbar normal-screen ">
        <div class="container">
            <div class="col-md-3">
                <a href="<?php echo e(route('home')); ?>" style="padding-top: 7px; display: block;">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" style="width: 90%;">
                </a>
            </div>
            <div class="col-md-9">
                <nav class="navbar">
                    <div class="container-fluid">
                        <ul class="nav navbar-nav navbar-right">
                            <?php $__currentLoopData = activeMainCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeMainCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li>
                                    <a href="#" class="normal-link">
                                        <i class="fa <?php echo e($activeMainCategory->icon); ?>"></i>
                                        <?php echo e($activeMainCategory->title); ?>

                                    </a>
                                    <?php if(count($activeMainCategory->categories)>0): ?>
                                        <div class="sub-nav">
                                            <div class="row">
                                                <?php $__currentLoopData = $activeMainCategory->categories->split(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $split): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <div class="col-md-4">
                                                        <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                            <a href="<?php echo e(route('cities.show',['city'=>urlencodeLink($category->name),'id'=>$category->id])); ?>">
                                                                <?php echo e($category->name); ?>

                                                            </a>
                                                            <?php if(count($category->items)>0): ?>
                                                                <ul>
                                                                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                        <li>
                                                                            <a href="<?php echo e(route('tour.show',['city'=>urlencodeLink($category->name),'tour'=>urlencodeLink($activeItems->name),'id'=>$activeItems->id])); ?>"
                                                                               title="<?php echo e($activeItems->title); ?>"><?php echo e(str_limit($activeItems->name,40,'...')); ?>

                                                                            </a>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                </ul>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('transfersShow')); ?>" class="additional-link">
                                    <i class="fa fa-car"></i> <?php echo e(Vars::getVar('Airport Transfers')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    
</section>

<?php $__env->startSection('_nav_js'); ?>
    <script>
        $(function () {
            $(window).scroll(function () {
                let topNavHeight = parseInt($('.top-nav').height());
                let mainMenu = $(".main-navbar");
                let scrollPoint = $(window).scrollTop();
                if (window.innerWidth > 797) {
                    if (scrollPoint >= topNavHeight && !mainMenu.hasClass('fixed-position')) {
                        mainMenu.addClass('fixed-position');
                    }
                    if (scrollPoint < topNavHeight && mainMenu.hasClass('fixed-position')) {
                        mainMenu.removeClass('fixed-position');
                    }
                }

            });

        });
    </script>
<?php $__env->stopSection(); ?>
