<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Shopping_Cart')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="booking-success">
                <h1>
                    <i class="fas fa-check"></i> <?php echo e(translate('Your_booking_is_done_!')); ?>

                </h1>
                <span class="booking-msg"><?php echo e(translate('Thank you for booking with us')); ?></span>

                <h2><?php echo e(translate('Payment Details')); ?></h2>
                <div class="payment-details">
                    <div class="row">
                        <div class="col-md-6">
                            <span><?php echo e(translate('Total Amount')); ?>:</span>
                            <?php echo e($reservation->total); ?> <?php echo e(payment()->currency_symbol); ?>

                        </div>
                        <div class="col-md-6">
                            <span><?php echo e(translate('Deposit Amount')); ?>:</span>
                            <?php echo e($reservation->deposit); ?> <?php echo e(payment()->currency_symbol); ?>

                        </div>
                    </div>
                    <?php if(!is_null($reservation->paymentId)): ?>
                        <div class="row">
                            <div class="col-md-6">
                                <span><?php echo e(translate('Payment Method')); ?>:</span>
                                <?php echo e($reservation->payment_method); ?>

                            </div>
                            <div class="col-md-6">
                                <span><?php echo e(translate('Transaction ID')); ?>:</span>
                                <?php echo e($reservation->paymentId); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <span class="booking-email-notify">
                    <?php echo e(translate('We have sent your booking details to')); ?> <?php echo e($reservation->customer->email); ?>

                </span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>