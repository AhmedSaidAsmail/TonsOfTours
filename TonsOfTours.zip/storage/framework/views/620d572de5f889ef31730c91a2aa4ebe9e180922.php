<?php $__env->startSection('Extra_Css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
    <style>
        .remove-button {
            border: none;
            background-color: transparent;
            padding: 0;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1> Web visitors
                <small>Visitors tables</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
                <li><a href="#">Visitors</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- box -->
                    <div class="box">
                        <div class="box-header with-border">
                            
                            <?php if(Session::has('alert')): ?>
                                <div class="alert <?php echo e(Session('alertType')); ?> alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                                        &times;
                                    </button>
                                    <h4><i class="icon fa fa-ban"></i> <?php echo e(Session('alert')); ?> </h4>
                                    <?php if(Session::has('alertDetails')): ?>
                                        ..<a href="#" id="errorDetails">Details</a>
                                        <p id="ErrorMsgDetails"><?php echo e(Session('alertDetails')); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                        </div>

                    </div>
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Web Visitors Data With Full Features</h3>
                        </div>
                        <div class="box-body">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Country</th>
                                    <th>State</th>
                                    <th>City</th>
                                    <th>Ip</th>
                                    <th>Last Visit</th>
                                    <th>#Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($visitor->country); ?></td>
                                        <td><?php echo e($visitor->state); ?></td>
                                        <td><?php echo e($visitor->city); ?></td>
                                        <td><?php echo e($visitor->ip); ?></td>
                                        <td><?php echo e($visitor->last_visit); ?></td>
                                        <td>
                                            <form method="post"
                                                  action="<?php echo e(route('site-visitor.destroy',['id'=>$visitor->id])); ?>"
                                                  id="itemDelete">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="DELETE">
                                            </form>
                                            <ul class="list-inline">
                                                <li>
                                                    <a href="<?php echo e(route('site-visitor.show',['id'=>$visitor->id])); ?>">
                                                        <i class="fa fa-search"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <button class="remove-button" form="itemDelete">
                                                        <i class="fa fa-trash-o fa-lg text-danger"></i>
                                                    </button>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <th>Country</th>
                                    <th>State</th>
                                    <th>City</th>
                                    <th>Ip</th>
                                    <th>Last Visit</th>
                                    <th>#Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
    <script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#dataTable').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": true,
                "ordering": true,
                "order": [[4, 'desc']],
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>