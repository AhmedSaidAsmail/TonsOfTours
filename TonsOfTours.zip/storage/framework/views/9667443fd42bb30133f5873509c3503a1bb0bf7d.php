<?php $__env->startSection('content'); ?>
<!-- welcome -->
<div class="main-box row">
    <div class="col-md-8">
        <?php if($topic->Topics_text): ?>
        <?php echo $topic->Topics_text->txt; ?>

        <?php endif; ?>
    </div>
    <div class="col-md-4">
        <?php $__currentLoopData = $topic->topics_image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row" style="margin-bottom: 10px;">
            <img src="<?php echo e(asset('images/gallery/thumb/'.$image->img)); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>