<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Directory&Header -->
        <section class="content-header">
            <h1> Reservations
                <small>Reservations Details</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
                <li><a href="#">Reservations</a></li>
            </ol>
        </section>
        <!-- end Directory&Header -->
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- box -->

                    <!-- end box 1 -->
                    <!-- /.box -->
                    <div class="box">
                        <div class="box-header">
                            Reservation Details
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-2">Name:</div>
                                <div class="col-md-4"><?php echo e($reservation->customer->name); ?></div>
                                <div class="col-md-2">Email:</div>
                                <div class="col-md-4"><?php echo e($reservation->customer->email); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">Mobile:</div>
                                <div class="col-md-4"><?php echo e($reservation->customer->information->phone); ?></div>
                                <div class="col-md-2">Date:</div>
                                <div class="col-md-4"><?php echo e(date('l, M d, Y',strtotime($reservation->date))); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">Total:</div>
                                <div class="col-md-4"><?php echo e($reservation->total.$reservation->currency); ?></div>
                                <div class="col-md-2">Deposit:</div>
                                <div class="col-md-4"><?php echo e($reservation->deposit.$reservation->currency); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">Approval:</div>
                                <div class="col-md-4">
                                    <?php if($reservation->approval): ?>
                                        <i class="fa fa-check fa-2x text-success"></i>
                                    <?php else: ?>
                                        <i class="fa fa-times fa-2x text-danger"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-2">Payment Method</div>
                                <div class="col-md-4"><?php echo e($reservation->payment_method); ?></div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">Transaction ID:</div>
                                <div class="col-md-4"><?php echo e($reservation->paymentId); ?></div>
                                <div class="col-md-2">Order number:</div>
                                <div class="col-md-4"><?php echo e($reservation->orderNumber); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php $__currentLoopData = $reservation->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="box">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h3><?php echo e($item->item->title); ?></h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">Total:</div>
                                    <div class="col-md-2"><?php echo e($item->total); ?></div>
                                    <div class="col-md-2">Deposit:</div>
                                    <div class="col-md-2"><?php echo e($item->deposit); ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <ul class="list-inline">
                                            <li><?php echo e($item->st_num); ?> <?php echo e($item->st_name); ?> * <?php echo e($item->st_price); ?></li>
                                            <li><?php echo e($item->sec_num); ?> <?php echo e($item->sec_name); ?> * <?php echo e($item->sec_price); ?></li>
                                        </ul>
                                    </div>
                                    <div class="col-md-2">Date</div>
                                    <div class="col-md-4"><?php echo e(date('l, M d, Y',strtotime($item->date))); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>