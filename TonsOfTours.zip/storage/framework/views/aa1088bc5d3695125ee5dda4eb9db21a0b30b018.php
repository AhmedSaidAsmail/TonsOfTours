<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Shopping_Cart')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="row cart-items-holder">
                <div class="col-md-8 checkout-form">
                    <h3>
                        Checkout
                        <span>all fields are required</span>
                    </h3>
                    <?php
                    $customer_id = null;
                    $first_name = null;
                    $last_name = null;
                    $email = null;
                    $phone = null;
                    if (Auth::guard('customer')->check()) {
                        $customer = Auth::guard('customer')->user();
                        $customer_id = $customer->id;
                        $first_name = substr(trim($customer->name), 0, strpos(trim($customer->name), " "));
                        $last_name = substr(trim($customer->name), strpos(trim($customer->name), " ") + 1);
                        $email = $customer->email;
                        $phone = $customer->information->phone;
                    }
                    ?>
                    <form action="<?php echo e(route('cart.checkout')); ?>"
                          method="post" <?php echo $cart->deposit>0?'id="checkOutForm"':null; ?>>
                        <?php echo e(csrf_field()); ?>

                        <input id="token" name="token" type="hidden" value="">
                        <input type="hidden" name="deposit" value="<?php echo e($cart->deposit); ?>">
                        <input type="hidden" name="total" value="<?php echo e($cart->total); ?>">
                        <input type="hidden" name="currency" value="<?php echo e(payment()->currency); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input class="form-control" name="first_name" value="<?php echo e($first_name); ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input class="form-control" name="last_name" value="<?php echo e($last_name); ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" name="email" value="<?php echo e($email); ?>" required>
                                    <div class="help-block">
                                        This is where we will send the booking confirmation
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Phone Number</label>
                                    <input class="form-control" name="phone" value="<?php echo e($phone); ?>" required>
                                    <div class="help-block">
                                        The tour operator will call this number if they need to reach you.
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($cart->deposit>0): ?>
                            
                            <?php echo $__env->make('frontEnd.cart.layouts.paymentOptions', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            
                            <?php echo $__env->make('frontEnd.cart.layouts.2checkoutForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <?php endif; ?>
                        <?php echo $__env->make('frontEnd.cart.layouts.checkoutSubmitButton', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </form>
                </div>
                <div class="col-md-4 checkout-review">
                    <h3><?php echo e(translate('Review_Order_Details')); ?></h3>
                    <section>
                        <?php $__currentLoopData = $cart->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php
                            $model = getItem($item->item_id);
                            ?>
                            <div class="row checkout-review-item">
                                <div class="col-md-7 col-xs-7 checkout-review-item-details">
                                    <h2><?php echo e($model->title); ?></h2>
                                    <?php if($item->st_num): ?>
                                        <span>
                                        <label class="numbers"><?php echo e($item->st_num); ?></label>
                                            <?php echo e($item->st_name); ?> ×
                                            <label class="numbers"><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->st_price)); ?></label>
                                            <?php echo e(payment()->currency); ?>

                                    </span>
                                    <?php endif; ?>
                                    <?php if($item->sec_num): ?>
                                        <span>
                                        <label class="numbers"><?php echo e($item->sec_num); ?></label>
                                            <?php echo e($item->sec_name); ?> ×
                                            <label class="numbers"><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->sec_price)); ?></label>
                                            <?php echo e(payment()->currency); ?>

                                    </span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-5 col-xs-5 checkout-review-item-prices">
                                    <span><?php echo e(translate('Total')); ?>

                                        :</span> <?php echo e(payment()->currency_symbol.sprintf('%.2f',$item->total)); ?>

                                    <?php if($item->deposit>0): ?>
                                        <span><?php echo e(translate('Deposit_Due')); ?>

                                            :</span> <?php echo e(payment()->currency_symbol.sprintf('%.2f',$item->deposit)); ?>

                                    <?php else: ?>
                                        <span><?php echo e(translate('No_Deposit')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row checkout-review-cancel">
                                <div class="col-md-12">
                                    <i class="fas fa-check"></i> <?php echo e(translate('Free_cancellation_before')); ?>

                                    <?php echo e(\Carbon\Carbon::parse($item->date)->subDay(2)->format('l, M d, Y')); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </section>
                    <section class="checkout-review-total">
                        <div class="row">
                            <div class="col-md-6">
                                <span><?php echo e(translate('total')); ?></span>
                            </div>
                            <div class="col-md-6 text-right">
                                <label><?php echo e(payment()->currency_symbol.sprintf('%.2f',$cart->total)); ?> <?php echo e(payment()->currency); ?></label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <span><?php echo e(translate('Deposit_due')); ?></span>
                            </div>
                            <div class="col-md-6 text-right">
                                <label><?php echo e(payment()->currency_symbol.sprintf('%.2f',$cart->deposit)); ?> <?php echo e(payment()->currency); ?></label>
                            </div>
                        </div>
                    </section>
                    <section>
                        <ul class="checkout-notify">
                            <li>
                                <span><?php echo e(translate('Lowest_Price_Guarantee')); ?></span>
                                <?php echo e(translate("Find_it_cheaper?_We'll_refund_the_difference")); ?>

                            </li>
                            <li>
                                <span><?php echo e(translate('24/7_Global_Support')); ?></span>
                                <?php echo e(translate('Get_the_answers_you_need,_when_you_need_them')); ?>

                            </li>
                            <li>
                                <span><?php echo e(translate('Book_Securely')); ?></span>
                                <i class="fas fa-lock"></i> <?php echo e(translate('We_use_SSL_encryption_to_keep_your_data_secure')); ?>

                            </li>
                        </ul>
                    </section>
                    <div class="having-trouble">
                        <span><?php echo e(translate('Having_trouble_booking_online?')); ?></span>
                        <span><?php echo e(translate('Call')); ?> <?php echo e(translate('info_phone')); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>