<?php echo $__env->make('frontEnd.layouts._loginForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section class="main-nav">
    
    <div class="row top-nav">
        <div class="container">
            <nav class="navbar">
                <div class="container-fluid">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="<?php echo e(route('wish-list.index')); ?>">
                                <i class="fas fa-heart"></i> WishList
                                <?php if(wishListsCount()): ?>
                                    <span class="header-numbers">(<?php echo e(wishListsCount()); ?>)<i
                                                class="fas fa-circle"></i></span>
                                <?php endif; ?>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('cart.index')); ?>">
                                <i class="fas fa-shopping-cart"></i> Cart
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fas fa-question-circle"></i> Help
                            </a>
                        </li>
                        <?php if(Auth::guard('customer')->check()): ?>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                    <i class="fa fa-user"></i> <?php echo e(Auth::guard('customer')->user()->name); ?>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="<?php echo e(route('customer.bookings')); ?>">
                                            <i class="fas fa-cart-arrow-down"></i> Bookings
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('customer.setting')); ?>">
                                            <i class="fas fa-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('customer.logout')); ?>">
                                            <i class="fas fa-sign-out-alt"></i> Logout
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="#" id="login">
                                    <i class="fas fa-user-circle"></i> Login
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('customer.register')); ?>">
                                    <i class="fas fa-user-plus"></i> Sign Up
                                </a>
                            </li>
                        <?php endif; ?>

                    </ul>


                </div>
            </nav>
        </div>
    </div>
    
    
    <div class="row main-navbar normal-screen ">
        <div class="container">
            <div class="col-md-3">
                <a href="<?php echo e(route('home')); ?>" class="nav-width-screen-logo">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="<?php echo e(Request::getHost()); ?>">
                    <span>find your wealth in treasured moments</span>
                </a>
            </div>
            <div class="col-md-9">
                <nav class="navbar">
                    <div class="container-fluid">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="responsive-title">
                                <?php echo e(translate('MAIN MENU')); ?>

                            </li>
                            <?php $__currentLoopData = activeMainCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeMainCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('home.mainCategory.show',['name'=>$activeMainCategory->name,'id'=>$activeMainCategory->id])); ?>"
                                       class="normal-link">
                                        <i class="fa <?php echo e($activeMainCategory->icon); ?>"></i>
                                        <?php echo e($activeMainCategory->title); ?>

                                    </a>
                                    <span class="pull-right-container">  </span>
                                    <?php if(count($activeMainCategory->categories)>0): ?>
                                        <div class="sub-nav">
                                            <div class="row">
                                                <?php $__currentLoopData = $activeMainCategory->categories->split(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $split): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <div class="col-md-4">
                                                        <?php $__currentLoopData = $split; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                            <a href="<?php echo e(route('home.category.show',['city'=>urlencodeLink($category->name),'id'=>$category->id])); ?>">
                                                                <?php echo e($category->name); ?>

                                                            </a>
                                                            <?php if(count($category->items)>0): ?>
                                                                <ul>
                                                                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                        <li>
                                                                            <a href="<?php echo e(route('home.item.show',['category'=>urlencodeLink($category->name),'name'=>urlencodeLink($activeItems->name),'id'=>$activeItems->id])); ?>"
                                                                               title="<?php echo e($activeItems->title); ?>"><?php echo e(str_limit($activeItems->name,40,'...')); ?>

                                                                            </a>
                                                                        </li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                                </ul>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <li>
                                <a href="#" class="additional-link">
                                    <i class="fas fa-phone-square"></i> <?php echo e(translate('Special_Assistance')); ?>

                                </a>
                            </li>
                            <li class="responsive-item">
                                <a href="">
                                    <i class="fas fa-question-circle"></i> Help
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    
</section>

<?php $__env->startSection('_nav_js'); ?>
    <script>
        $(function () {
            $(window).scroll(function () {
                let topNavHeight = parseInt($('.top-nav').height());
                let mainMenu = $(".main-navbar");
                let scrollPoint = $(window).scrollTop();
                if (window.innerWidth > 797) {
                    if (scrollPoint >= topNavHeight && !mainMenu.hasClass('fixed-position')) {
                        mainMenu.addClass('fixed-position');
                    }
                    if (scrollPoint < topNavHeight && mainMenu.hasClass('fixed-position')) {
                        mainMenu.removeClass('fixed-position');
                    }
                }

            });

        });
    </script>
<?php $__env->stopSection(); ?>
