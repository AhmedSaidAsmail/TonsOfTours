
<!-- header menu -->
<div class="row" style="position: absolute; z-index: 3000; left: 0px; width: 100%; background-color: rgba(0,0,0,0.2);
     border-bottom: 1px outset #FFF;">
    <div class="container" style=" ">
        <nav class="navbar" id="header-nav" style=" min-height: 0px;">
            <div class="container-fluid headerLinks">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('home')); ?>"><span class="glyphicon glyphicon-home"></span><?php echo e(Vars::getVar("Home")); ?></a></li>
                    <li><a href="<?php echo e(route('cart')); ?>"><span class="glyphicon glyphicon-shopping-cart"></span>Cart <span class="badge" id="shoping-cart-header">
                                <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?>

                            </span></a></li>
                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($top->name)])); ?>">
                            <?php if(!is_null($top->icon)): ?>
                            <span class="glyphicon <?php echo e($top->icon); ?>"></span>
                            <?php endif; ?>
                            <?php echo e($top->top_link); ?> </a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <!-- <li><a href="" ><span class="glyphicon glyphicon-question-sign"></span><?php echo e(Vars::getVar("Help")); ?></a></li>-->
                </ul>


            </div>
        </nav>
    </div>
</div>
<!-- end header menu -->
<!-- navigator Menu -->
<div class="row main-nav-normal animated" id="main-nav">

    <div class="container" id="responsive-nav" >
        <div class="col-sm-2 col-xs-2 mob-menu" >
            <div id="responsive-menu">
                <i class="fa fa-bars" aria-hidden="true"></i>
                MENU
            </div>
        </div>
        <div class="col-md-2 logo-conatiner col-sm-8 col-xs-8">
            <span class="logo-header logo-header-position"></span></div>

        <div class="col-sm-2 col-xs-2 mob-cart">
            <a href=""><span class="glyphicon glyphicon-shopping-cart"></span> <span class="badge">0</span></a>
        </div>
        <div class="col-md-10">
            <ul id="main-nav-main" style="position: relative;">
                <?php $__currentLoopData = App\MyModels\Admin\Basicsort::where('home','=','1')->limit(4)->orderBy('arrangement','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortMenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><a href="#" class="normal-link"><i class="fa <?php echo e($sortMenu->icon); ?>"></i> <?php echo e($sortMenu->title); ?></a>
                    <?php if(count($sortMenu->sorts)>0): ?>
                    <div class=" row submenu">
                        <?php $__currentLoopData = $sortMenu->sorts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="row">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col-md-4">
                                <h2><a href="<?php echo e(route('cities.show',['city'=>urlencode($category->name),'id'=>$category->id])); ?>" style="color:#5e5e5e;"><?php echo e($category->name); ?></a></h2>

                                <?php if(count($category->items)>0): ?>
                                <ul>
                                    <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemmenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($itemmenu->name),'id'=>$itemmenu->id])); ?>" title="<?php echo e($itemmenu->title); ?>"><?php echo e(substr($itemmenu->name,0,30)); ?></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <!-- start navigator menu -->

                <li><a href="<?php echo e(route('transfersShow')); ?>" class="normal-link"><i class="fa fa-car"></i> <?php echo e(Vars::getVar('Airport Transfers')); ?></a></li>
                <li><a href="<?php echo e(route('hotDeals')); ?>" class="normal-link"><i class="fa fa-heart"></i><?php echo e(Vars::getVar('Hot_Offers')); ?></a></li>

            </ul>
        </div>

    </div>
</div>
<!-- end navigator menu -->