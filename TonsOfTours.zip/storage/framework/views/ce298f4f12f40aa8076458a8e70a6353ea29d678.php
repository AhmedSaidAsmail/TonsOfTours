<div id="general" class="tab-pane fade in active">
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Category</label>
                <select name="category_id" class="form-control select-options" required>
                    <option value="">Select a Category</option>
                    <?php $__currentLoopData = categoriesAll(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        $selected = !is_null($item) && $category->id == $item->category_id ? "selected" : null;
                        ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($selected); ?>><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Name</label>
                <input name="name" value="<?php echo e(itemValueResolve("name",$item)); ?>" class="form-control" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Title</label>
                <input name="title" value="<?php echo e(itemValueResolve("title",$item)); ?>" class="form-control" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Meta Keywords</label>
                <input name="keywords" value="<?php echo e(itemValueResolve("keywords",$item)); ?>" class="form-control">

                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Meta Description</label>
                <input name="description" value="<?php echo e(itemValueResolve("description",$item)); ?>" class="form-control">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Status</label>
                <select name="status" class="form-control">
                    <?php $status = itemValueResolve('status', $item); ?>
                    <option value="1">show</option>
                    <option value="0" <?php echo !$status&&!is_null($status)?"selected":null; ?>>hidden</option>
                </select>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Recommended</label>
                <select name="recommended" class="form-control">
                    <?php $recommended = itemValueResolve('recommended', $item); ?>
                    <option value="1">true</option>
                    <option value="0" <?php echo !$recommended&&!is_null($recommended)?"selected":null; ?>>false</option>
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Hot Offer</label>
                <select name="recommended" class="form-control">
                    <?php $offer = itemValueResolve('offer', $item); ?>
                    <option value="1">true</option>
                    <option value="0" <?php echo !$offer&&!is_null($offer)?"selected":null; ?>>false</option>
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Arrangement</label>
                <input type="number" name="arrangement" value="<?php echo e(sprintf('%d',itemValueResolve("arrangement",$item))); ?>" class="form-control">
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Intro Image</label>
                <input type="file" name="img" class="form-control">
            </div>
        </div>
    </div>
</div>