<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'Home')->first() ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<div class="row" style="position: relative;">
    <?php echo $__env->make('Web.Layouts.MainMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">

        <div class="carousel-inner">
            <div class="item active">
                <img src="images/flash001.jpg" alt="Chania">

            </div>


        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev" style="background-image: none;" >
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next" style="background-image: none;">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- real insider -->
<div class="container welcome-body">
    <!-- Welcome Search -->
    <div class="search-sliders">
        <div class="search-sliders-insiders">
            <h2 class="banner-title">Let the activities begin!</h2>
            <div class="row" style="margin-top: 10px;">
                <form action="<?php echo e(route('Web.searchItems')); ?>" method="get" id="serach-items-result">
                    <div class="col-md-10 col-sm-8 col-xs-8" style=" padding: 0px; position: relative;">
                        <input type="text" class="form-control welcome-search-input" id="welcome-search" placeholder="Search for destentions, attraction and tours" >
                        <div class="welcome-search-result" id="search-result">
                            <!-- search Result -->
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-4 col-xs-4" style=" padding: 0px;">
                        <button  class="btn btn-primary" style="width: 100%; border-radius: 0px; font-size: 17px; padding-top: 3px;">LETS GO</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end Welcome Search -->


    <?php $__currentLoopData = $Categories->sortBy('arrangement'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row">
        <h1 class="text-center welcome-title"><?php echo e($category->slogan); ?>

            <span class="glyphicon glyphicon-circle-arrow-right"></span></h1>
        <h4 class="text-center welcome-title2"><?php echo e($category->slogan2); ?></h3>
    </div>
    <?php $__currentLoopData = $category->items->where('recommended',"=",1)->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row welcome-items">
        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-4" >
            <div class="welcome-item">
                <?php if($item->offer): ?>
                <div class="hot-offers"></div>
                <?php endif; ?>

                <div class="thumb-one row">
                    <div class="col-md-6">
                        <?php if(isset($item->price)): ?>
                        <?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                        <?php endif; ?>
                        <span class="price-currency-label"><?php echo e(Vars::getVar("$")); ?></span></div>
                    <div class="col-md-6" style=" text-align: right;">
                        <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>" style="color:inherit; text-decoration: none;">
                            <?php echo e(Vars::getVar('Add_to_basket')); ?> <i class="fa fa-cart-plus" style="color: #67ab34;" ></i>
                        </a>
                    </div>
                </div>
                <div class="welcome-item-img-container">
                    <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">
                        <img src="<?php echo e(asset('images/items/'.$item->img)); ?>"  alt="<?php echo e($item->title); ?>" style="width: 100%;">
                    </a>
                </div>

                <div class="welcome-item-txt-container">
                    <div class="welcome-img-border">
                        <span class="glyphicon glyphicon-triangle-top"></span>
                    </div>
                    <h2><?php echo e($item->name); ?></h2>
                    <?php
                    echo substr($item->intro, 0, 90);
                    ?>

                    ...<a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">Read More</a>

                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <div class="row text-center">
        <a href="<?php echo e(route('cities.show',['city'=>urlencode($category->name),'id'=>$category->id])); ?>" class="btn btn-info btn-lg">Show more attractions</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>