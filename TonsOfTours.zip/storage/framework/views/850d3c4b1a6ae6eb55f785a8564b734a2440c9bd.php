
<?php $__env->startSection('title','Items Panel | Update'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1>Items <small>Gallery</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Update Items :<?php echo e(App\MyModels\Admin\Item::find($itemID)->name); ?> </a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-money"></i> Price List</a></h3>
                    </div>
                    <div class="box-body">
                        <form method="post" action="<?php echo e(route('Price.update',['itemID'=>$itemID,'id'=>$price->id])); ?>">
                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                            <input type='hidden' value="PUT" name="_method">
                            <div class="row margin-bottom">
                                <div class="form-group">
                                    <div class="col-md-3"><input class="form-control" type="text" value="<?php echo e($price->st_name); ?>" name="st_name" placeholder="First Price Name"></div>
                                    <div class="col-md-3"><input class="form-control" type="text" value="<?php echo e($price->st_price); ?>" name="st_price" placeholder="First Price"></div>
                                    <div class="col-md-3"><input class="form-control" type="text" value="<?php echo e($price->sec_name); ?>" name="sec_name" placeholder="Second Price Name"></div>
                                    <div class="col-md-3"><input class="form-control" type="text" value="<?php echo e($price->sec_price); ?>" name="sec_price" placeholder="Second Price"></div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <a href="<?php echo e(route('Items.edit',['item'=>$itemID])); ?>" class="btn btn-bitbucket"><i class="fa fa-dashboard"></i> Return Back to Item Dashboard</a>
                                        <button class="btn btn-primary"><i class="fa fa-paw"></i> Update Details</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>