<!doctype html>
<html lang="en">
    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php echo $__env->yieldContent('meta_tags'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <?php echo $__env->yieldContent('_extra_css'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    </head>
    <body id="exc">
        <?php echo $__env->yieldContent('extra-plugged-in'); ?>

        <!-- header -->
        <?php echo $__env->yieldContent('header-nav'); ?>

        <!-- end header -->
        <!-- content -->
        <?php echo $__env->yieldContent('content'); ?>


        <!-- footer -->
        <div class="row footer">
            <div class="container" style="position: relative;">

                <div class="row">

                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('footer',1)->orderBy('arrangement','desc')->limit(9)->get()->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footerChunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-6">
                        <ul>
                            <?php $__currentLoopData = $footerChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($footer->name)])); ?>"><?php echo e($footer->footer_link); ?> </a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>



                    <div class="col-md-3">
                        <div class="row">
                            <span class="glyphicon glyphicon-envelope" style="margin-right: 10px; font-size: 20px;"></span>Newsletter: Get the best travel deals delivered to your inbox!
                        </div>
                        <div class="row">
                            <form>
                                <div class="col-md-10 col-sm-10 col-xs-10" style="padding-left: 0px; padding-right: 0px;">
                                    <input type="text" value="" class="form-control" placeholder="Your mail">
                                </div>
                                <div class="col-md-2 col-sm-2 col-xs-2" style="padding-left: 5px;">
                                    <button class="btn btn-success" style="padding: 5px;"><i class="fa fa-check" style="font-size: 20px;"></i></button>
                                </div>
                            </form>
                        </div>
                        <div class="row footer-social-links">
                            <div class="col-md-12 col-sm-8 col-xs-8">
                                <a href="<?php echo e(Vars::getVar('facebook-link')); ?>"> <i class="fa fa-facebook"></i></a>
                                <a href="<?php echo e(Vars::getVar('twitter-link')); ?>"> <i class="fa fa-twitter"></i></a>
                                <a href="<?php echo e(Vars::getVar('google-link')); ?>"> <i class="fa fa-google-plus"></i></a>
                                <a href="<?php echo e(Vars::getVar('pin-link')); ?>"> <i class="fa fa-pinterest-p"></i></a>
                                <a href="#"> <i class="fa fa-feed"></i></a>
                            </div>
                        </div>
                    </div>
                </div>


            </div>

        </div>

        <div class="row text-center" style="background-color: #f2f2f2; padding: 10px;">© 2017 www.holidaysinegypt.net All Rights Reserved</div>
        <div class="row footer-share-bottom">
            <div class="col-md-3 footer-share-div twiter-share" onclick="location.href = '<?php echo e(Vars::getVar('twitter-link')); ?>'">
                <div class="footer-share-text"><i class="fa fa-twitter"></i><?php echo e(Vars::getVar('FOLLOW_US')); ?></div>
            </div>
            <div class="col-md-3 footer-share-div facebook-share" onclick="location.href = '<?php echo e(Vars::getVar('facebook-link')); ?>'">
                <div class="footer-share-text"><i class="fa fa-facebook"></i><?php echo e(Vars::getVar('LIKE_US')); ?></div>
            </div>
            <div class="col-md-3 footer-share-div footer-google" onclick="location.href = '<?php echo e(Vars::getVar('google-link')); ?>'">
                <div class="footer-share-text"><i class="fa fa-google-plus"></i><?php echo e(Vars::getVar('CONNECT')); ?></div>
            </div>
            <div class="col-md-3 footer-share-div footer-pin" onclick="location.href = '<?php echo e(Vars::getVar('pin-link')); ?>'">
                <div class="footer-share-text"><i class="fa fa-pinterest-p"></i><?php echo e(Vars::getVar('PIN_US')); ?></div>
            </div>
        </div>

        <script src="<?php echo e(asset('js/jquery-2.2.3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/per.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('_extra_js'); ?>
    </body>
</html>
