<?php $__env->startSection('meta_tags'); ?>
    <meta name="keywords" content="<?php echo e($item->keywords); ?>"/>
    <meta name="description" content="<?php echo e($item->description); ?>"/>
    <title><?php echo e($item->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <img class="aspect-img" src="<?php echo e(asset('images/items/'.$item->img)); ?>"
             alt="<?php echo e($item->title); ?>">
        <div class="insider-header-contains">
            <div class="container">
                <a href="<?php echo e(asset('images/items/'.$item->img)); ?>?image=100" class="more-photos" data-toggle="lightbox"
                   data-gallery="<?php echo e($item->title); ?>">
                    <i class="fas fa-camera"></i>
                    <span><?php echo e(translate('More_photos')); ?></span>
                </a>
                <div class="item-gallery">
                    
                        
                           
                            
                        
                    
                </div>
                <ul class="list-inline dir">
                    <?php
                    $mainCategory = $item->category->mainCategory;
                    $category = $item->category;
                    ?>
                    <li>
                        <a href="<?php echo e(route('home.mainCategory.show',['name'=>urlencodeLink($mainCategory->name),'id'=>$mainCategory->id])); ?>">
                            <?php echo e($mainCategory->name); ?>

                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('home.category.show',['name'=>urlencodeLink($category->name),'id'=>$category->id])); ?>">
                            <?php echo e($category->name); ?>

                        </a>
                    </li>
                    <li><?php echo e($item->title); ?></li>
                </ul>
                <h1 class="item-title-responsive"><?php echo e($item->title); ?></h1>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="row item-holder">
                <div class="col-md-8">
                    <ul class="list-inline symbol-references">
                        <li>
                            <i class="far fa-comment-alt"></i> Offered in: English and other
                        </li>
                        <?php if(!is_null($item->details)): ?>
                            <?php if(!is_null($item->details->duration)): ?>
                                <li>
                                    <i class="far fa-clock"></i> <?php echo e($item->details->duration); ?>

                                </li>
                            <?php endif; ?>
                            <?php if(!is_null($item->details->transfer)): ?>
                                <li>
                                    <i class="fas fa-bus-alt"></i> Pick-up service
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <li>
                            <i class="fas fa-credit-card"></i> Cancellation: up 2 Days
                        </li>
                    </ul>
                    <ul class="list-inline item-main-nav-bar">
                        <li class="active"><a href="#overview" id="scrollTo">Overview</a></li>
                        <li><a href="#itinerary" id="scrollTo">Itinerary</a></li>
                        <li><a href="#price" id="scrollTo">Prices</a></li>

                    </ul>
                    <div class="intro" id="overview">
                        <?php echo e($item->intro); ?>

                    </div>
                    <?php if($item->includes->count()>0): ?>
                        <h1 class="item-header"><?php echo e(translate('Include')); ?></h1>
                        <ul class="item-includes">
                            <?php $__currentLoopData = $item->includes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $include): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li><?php echo e(trim(str_replace('•','',$include->txt))); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <?php if($item->excludes->count()>0): ?>
                        <h1 class="item-header"><?php echo e(translate('Excludes')); ?></h1>
                        <ul class="item-excludes">
                            <?php $__currentLoopData = $item->excludes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclude): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li><?php echo e(trim(str_replace('*','',$exclude->txt))); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <?php if(isset($item->exploration)): ?>
                        <h1 class="item-header" id="itinerary"><?php echo e(translate('Itinerary')); ?></h1>
                        <div class="panel-group" id="accordion">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"
                                           href="#collapse5" aria-expanded="true">
                                            <?php echo e(translate('Highlights')); ?>

                                        </a>
                                    </h4>
                                </div>
                                <div id="collapse5" class="panel-collapse collapse in" aria-expanded="true" style="">
                                    <div class="panel-body">
                                        <?php echo $item->exploration->txt; ?>

                                    </div>
                                </div>
                            </div>


                        </div>
                    <?php endif; ?>
                    <?php if(isset($item->price)): ?>
                        <h1 class="item-header" id="price"><?php echo e(translate('Prices')); ?></h1>
                        <div class="item-prices-container">
                            <div class="row">
                                <div class="col-md-5 price-references">
                                    <div class="price-package">
                                        <span class="only"><?php echo e(translate('Price_per_Pax')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-7">
                                    <ul>
                                        <li><?php echo e(payment()->currency_symbol); ?> <b><?php echo e($item->price->st_price); ?></b>
                                            <?php echo e(translate('Price_per')); ?> <?php echo e($item->price->st_name); ?>

                                        </li>
                                        <li><?php echo e(payment()->currency_symbol); ?> <b><?php echo e($item->price->sec_price); ?></b>
                                            <?php echo e(translate('price_per')); ?> <?php echo e($item->price->sec_name); ?>

                                        </li>

                                    </ul>
                                </div>
                            </div>
                            <?php if($item->packages->count()>0): ?>
                                <?php $__currentLoopData = $item->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-5 price-references">
                                            <div class="price-package">
                                                <span><?php echo e(translate('Price_per_Pax')); ?></span>
                                                <span>
                                                    (
                                                    <?php echo e(translate('from')); ?> <b><?php echo e($package->min); ?></b> <?php echo e('to'); ?>

                                                    <b><?php echo e($package->max); ?></b> <?php echo e(translate('pax')); ?>

                                                    )
                                                </span>
                                            </div>
                                        </div>
                                        <div class="col-md-7">
                                            <ul>
                                                <li><?php echo e(payment()->currency_symbol); ?> <b><?php echo e($package->st_price); ?></b>
                                                    <?php echo e(translate('Price_per')); ?> <?php echo e($item->price->st_name); ?>

                                                </li>
                                                <li><?php echo e(payment()->currency_symbol); ?> <b><?php echo e($package->sec_price); ?></b>
                                                    <?php echo e(translate('price_per')); ?> <?php echo e($item->price->sec_name); ?>

                                                </li>

                                            </ul>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-4">
                    <?php echo $__env->make('frontEnd.layouts._bookingForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
    <script type="text/javascript"
            src="https://cdnjs.cloudflare.com/ajax/libs/ekko-lightbox/5.3.0/ekko-lightbox.js"></script>
    <script>
        $(document).on('click', '[data-toggle="lightbox"]', function (event) {
            event.preventDefault();
            $(this).ekkoLightbox({
                maxHeight: 500
            });
        });
        $("a#scrollTo").on('click', function (event) {
            let scrollTo = $(this).attr('href');
            event.preventDefault();
            $('html, body').animate({
                scrollTop: ($(scrollTo).offset().top - 100)
            }, 500)
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>