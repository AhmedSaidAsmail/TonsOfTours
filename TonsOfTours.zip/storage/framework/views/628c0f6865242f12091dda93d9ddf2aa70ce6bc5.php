<div id="over_view" class="tab-pane fade">
    <h3>OverView</h3>

    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label>OverView</label>
                <textarea class="form-control" name="intro" required><?php echo e(getValue('intro',$item)); ?></textarea>
            </div>
        </div>
    </div>

</div>