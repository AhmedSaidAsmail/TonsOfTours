<?php if(count($errors)>0): ?>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fas fa-times-circle"></i>
        </button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php if(Session::has('failure')): ?>
    <div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fas fa-times-circle"></i>
        </button>
        <?php echo Session::get('failure'); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
            <i class="fas fa-times-circle"></i>
        </button>
        <?php echo Session::get('success'); ?>

    </div>
<?php endif; ?>