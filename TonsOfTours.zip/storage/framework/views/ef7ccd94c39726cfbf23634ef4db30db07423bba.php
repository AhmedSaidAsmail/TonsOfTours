<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <a href="">
        <div class="row">
            <div class="col-md-2 col-xs-1 col-sm-1">
                <img src="<?php echo e(asset('images/items/thumbSm/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>">
            </div>
            <div class="col-md-10 col-xs-11 col-sm-11">
                <h3><?php echo preg_replace("/$keyword/i","<b>".ucfirst($keyword)."</b>",$item->title); ?></h3>
                <?php if(isset($item->price)): ?>
                    <span><?php echo e(sprintf('%.2f',$item->price->st_price)); ?> $ <?php echo e(translate('per_person')); ?></span>
                <?php endif; ?>
            </div>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>