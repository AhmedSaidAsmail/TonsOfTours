<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Directory&Header -->
    <section class="content-header">
        <h1> Reservations <small>Reservations Details</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Reservations</a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->

                <!-- end box 1 -->
                <!-- /.box -->
                <div class="box">
                    <div class="box-header">
                        Reservation Details
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-2">Name:</div>
                            <div class="col-md-4"><?php echo e($reservation->f_name); ?> <?php echo e($reservation->sur_name); ?>  </div>
                            <div class="col-md-2">Email:</div>
                            <div class="col-md-4"><?php echo e($reservation->email); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Hotel:</div>
                            <div class="col-md-4"><?php echo e($reservation->hotel); ?></div>
                            <div class="col-md-2">Mobile:</div>
                            <div class="col-md-4"><?php echo e($reservation->mobile); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Date:</div>
                            <div class="col-md-10"><?php echo e($reservation->date); ?></div>

                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                Arrival Flight No:
                            </div>
                            <div class="col-md-4">
                                <?php echo e($reservation->arrival_flight_no); ?>

                            </div>
                            <div class="col-md-2">
                                Arrival Flight Time:
                            </div>
                            <div class="col-md-4">
                                <?php echo e($reservation->arrival_flight_time); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                Departure Flight No:
                            </div>
                            <div class="col-md-4">
                                <?php echo e($reservation->departure_flight_no); ?>

                            </div>
                            <div class="col-md-2">
                                Departure Flight Time:
                            </div>
                            <div class="col-md-4">
                                <?php echo e($reservation->departure_flight_time); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Tours:</div>
                            <div class="col-md-4"><?php echo e($reservation->tours); ?></div>
                            <div class="col-md-2">Transfers:</div>
                            <div class="col-md-4"><?php echo e($reservation->transfers); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Total:</div>
                            <div class="col-md-4"><?php echo e($reservation->total); ?></div>
                            <div class="col-md-2">Deposit:</div>
                            <div class="col-md-4"><?php echo e($reservation->deposit); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Paid Status:</div>
                            <div class="col-md-4">
                                <?php if($reservation->paid): ?>
                                Done
                                <?php else: ?>
                                Not Yet
                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">Created at</div>
                            <div class="col-md-4"><?php echo e($reservation->created_at); ?></div>
                        </div>
                        <div class="row" style="margin-top: 30px;">
                            <div class="col-md-12">
                                <a href="" class="btn btn-info btn-block"><i class="fa fa-mail-forward"></i>Send Email</a>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if(count($reservation->selfTours)>0): ?>
                <?php $__currentLoopData = $reservation->selfTours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="box">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <h3><?php echo e($tour->title); ?></h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Price:</div>
                            <div class="col-md-2"><?php echo e($tour->price); ?></div>
                            <div class="col-md-2">Date:</div>
                            <div class="col-md-2"><?php echo e($tour->date); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?php echo e($tour->st_name); ?></div>
                            <div class="col-md-2"><?php echo e($tour->st_no); ?></div>
                            <div class="col-md-2">Price</div>
                            <div class="col-md-2"><?php echo e($tour->st_price); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"><?php echo e($tour->sec_name); ?></div>
                            <div class="col-md-2"><?php echo e($tour->sec_no); ?></div>
                            <div class="col-md-2">Price</div>
                            <div class="col-md-2"><?php echo e($tour->sec_price); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php endif; ?>
                <?php if(count($reservation->selfTransfers)>0): ?>
                <?php $__currentLoopData = $reservation->selfTransfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transfer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="box">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <h3><?php echo e($transfer->title); ?></h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Price:</div>
                            <div class="col-md-2"><?php echo e($transfer->price); ?></div>
                            <div class="col-md-2">Arrival Date:</div>
                            <div class="col-md-2"><?php echo e($transfer->arrival_date); ?></div>
                            <div class="col-md-2">Departure Date:</div>
                            <div class="col-md-2"><?php echo e($transfer->departure_date); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">From</div>
                            <div class="col-md-2"><?php echo e($transfer->dist_from); ?></div>
                            <div class="col-md-2">To</div>
                            <div class="col-md-2"><?php echo e($transfer->dist_to); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Transfer Type</div>
                            <div class="col-md-2"><?php echo e($transfer->transfer_type); ?></div>
                            <div class="col-md-2">Transfers Times</div>
                            <div class="col-md-2"><?php echo e($transfer->transfer_times); ?></div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">Adult</div>
                            <div class="col-md-2"><?php echo e($transfer->adult); ?></div>
                            <div class="col-md-2">Child</div>
                            <div class="col-md-2"><?php echo e($transfer->child); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script>
$(function() {
    $("#example1").DataTable();
    $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>