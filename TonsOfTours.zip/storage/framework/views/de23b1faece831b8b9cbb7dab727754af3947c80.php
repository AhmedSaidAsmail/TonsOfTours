<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type" />
        <meta content="ahmed" name="author" />
        <?php echo $__env->yieldContent('meta_tags'); ?>
        <link href="<?php echo e(asset('images/icon.ico')); ?>" rel="icon" type="image/x-icon" />
        <link rel="stylesheet" href=<?php echo e(asset('adminlte/bootstrap/css/bootstrap.min.css')); ?> />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Muli" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Orbitron" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/cart.css')); ?>"/>
        <?php echo $__env->yieldContent('_extra_css'); ?>
    </head>
    <body>
        <div id="wrapper">
            <div id="container">
                <div class="row">
                    <div id="header">
                        <div id="language">
                            <div id="languages">
                                <div id="flages">
                                    <a href="http://egyptlandtours.com/" class="notend" target="_blank" title="Deutsch" >
                                        <img src="<?php echo e(asset('images/germany-flag.png')); ?>" alt="Deutsch" /></a>
                                    <a href="http://egyptlandtours.com/en" class="notend" target="_blank" title="English">
                                        <img src="<?php echo e(asset('images/english-flag.png')); ?>" alt="English" /></a>
                                    <a href="http://egyptlandtours.com/fr" class="notend" target="_blank" title="français" >
                                        <img src="<?php echo e(asset('images/france-flag.png')); ?>" alt="Frances" /></a>
                                    <a href="http://egyptlandtours.com/sp" class="notend" target="_blank" title="Español" >
                                        <img src="<?php echo e(asset('images/spain-flag.png')); ?>" alt="spaniol" /></a>
                                    <a href="http://egyptlandtours.com/it" class="notend" target="_blank" title="italiano" >
                                        <img src="<?php echo e(asset('images/italy-flag.png')); ?>" alt="ialino" /></a>
                                </div>
                            </div>
                        </div>
                        <div id="links">
                            <a href="<?php echo e(route('cart')); ?>" class="shoping_cart">
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i> <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?> </a>
                            <ul>
                                <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($top->name)])); ?>"><?php echo e($top->top_link); ?> </a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div id="banner">
                        <div class="flash"> <img src="<?php echo e(asset('images/logo-small.png')); ?>" alt="sharmland.com"/> </div>
                        <div class="slideshow">
                            <!-- /.box-header -->
                            <div class="box-body">
                                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner">
                                        <div class="item active"> <img src="<?php echo e(asset('images/slides/p_0001.jpg')); ?>" alt="First slide"> </div>
                                        <div class="item"> <img src="<?php echo e(asset('images/slides/p_0002.jpg')); ?>" alt="Second slide"> </div>
                                        <div class="item"> <img src="<?php echo e(asset('images/slides/p_0003.jpg')); ?>" alt="Third slide"> </div>
                                        <div class="item"> <img src="<?php echo e(asset('images/slides/p_0004.jpg')); ?>" alt="Third slide"> </div>
                                        <div class="item"> <img src="<?php echo e(asset('images/slides/p_0005.jpg')); ?>" alt="Third slide"> </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <nav class="navbar">
                        <div class="container-fluid">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                                    <i class="fa fa-bars" aria-hidden="true"></i> </button>
                            </div>
                            <div class="collapse navbar-collapse" id="myNavbar">
                                <ul class="nav navbar-nav">
                                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(Vars::getVar("home")); ?></a></li>

                                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li id="navbarHidden"><a href="<?php echo e(route('topics.show',['topicsName'=>urlencode($top->name)])); ?>"><?php echo e($top->top_link); ?> </a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                </ul>
                                <form class="navbar-form navbar-right">
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Search">
                                            <div class="input-group-btn">
                                                <button class="btn btn-default" type="submit"> <i class="glyphicon glyphicon-search"></i> </button>
                                            </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </nav>
                </div>
                <div id="real-body" class="row">
                    <!-- right Side -->
                    <div class="col-md-9 col-md-push-3">
                        <div class="insider">
                            <!-- container -->
                            <?php echo $__env->yieldContent('content'); ?>
                            <!-- end container -->
                        </div>
                    </div>
                    <!-- end right Side -->
                    <!-- left Side -->
                    <div class="col-md-3 col-md-pull-9" style="padding: 0px;">
                        <?php echo $__env->yieldContent('leftside_extra'); ?>
                        <div id="leftside">
                            <?php $__currentLoopData = App\MyModels\Admin\Leftsideicon::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <a href="<?php echo e($icon->link); ?>" target="_blank"><img src="<?php echo e(asset("images/icons/".$icon->img)); ?>"></img></a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                            <div class="row">
                                <div class="col-md-12">
                                    <!-- weather casting -->
                                    <div  style="margin:10px 0px 0px 0px ;">
                                        <div style="line-height: 10px; background: none;">
                                            <div style="max-width: 160px; width: 160px; background: none; margin: 0 auto;">
                                                <object id="w4aaa9c4e6c122b4c4af9ecec7aeeb33a" data="http://static.hotelscombined.com.s3.amazonaws.com/swf/weather_widget.swf" height="272" style="margin: 0; padding: 0;" type="application/x-shockwave-flash" width="160">
                                                    <param name="movie" value="http://static.hotelscombined.com.s3.amazonaws.com/swf/weather_widget.swf" />
                                                    <param name="wmode" value="transparent" />
                                                    <param name="flashvars" value="station_id=HESH&amp;city_name=Sharm el-Sheikh&amp;language=en&amp;use_celsius=Yes&amp;skinName=Blue&amp;PID=163946&amp;ts=201401180634&amp;hideChangeSkin=No" />
                                                    <param name="allowNetworking" value="all" />
                                                    <param name="allowScriptAccess" value="always" />
                                                </object>
                                                <a alt="Hotels Combined" href="http://widgets.hotelscombined.com/City/Weather/Sharm_el%20Sheikh.htm?use_celsius=Yes" style="margin: 0; padding: 0; text-decoration: none; background: none;" target="_blank" title="Hotels Combined">
                                                    <div style="background: none; color: white; text-align: center; width: 160px; height: 17px; margin: 0px 0 0 0; padding: 5px 0 0 0; cursor: pointer; background: transparent url(http://static.hotelscombined.com.s3.amazonaws.com/Pages/WeatherWidget/Images/weather_blue_bottom.png) no-repeat; font-size: 12px; font-family: Arial,sans-serif; line-height: 12px; font-weight: bold;"> See 10-Day Forecast</div>
                                                </a>
                                                <div style="text-align: center; width: 160px;"> <a alt="Hotels Combined" href="http://www.hotelscombined.com" rel="nofollow" style="background: none; font-family: Arial,sans-serif; font-size: 9px; color: #777777;" title="Hotels Combined"> © HotelsCombined.com</a></div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End weather casting -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end left Side -->

                </div>
                <div id="foter" class="row">
                    <ul>
                        <?php $__currentLoopData = App\MyModels\Admin\Topic::where('footer',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $footer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><a href="index.php"><?php echo e($footer->footer_link); ?> </a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                    </ul>
                    <p>&copy; All Right Reserved , EgyptLand Tours co. 2011 </p>
                    <p>Powered by <a href="mailto:info.matrixcode@gamil.com">MSMS Sites</a></p>
                </div>
            </div>
        </div>
        <!------------------------------ Java Scripts ---------------------->
        <script src="<?php echo e(asset('adminlte/plugins/jQuery/jquery-2.2.3.min.js')); ?>"></script>
        <script src="<?php echo e(asset('adminlte/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <?php echo $__env->yieldContent('_extra_js'); ?>

        <!------------------------------ Java Scripts   ---------------------->
    </body>
</html>
