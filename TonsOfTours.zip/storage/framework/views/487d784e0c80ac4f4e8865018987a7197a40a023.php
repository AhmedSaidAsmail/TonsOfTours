<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'Home')->first() ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row exc-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row" style="margin-bottom: 20px; border: 1px outset #6a97ae; border-radius: 10px; overflow: hidden;">
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <i class="fa fa-cart-plus"></i> <?php echo e(Vars::getVar("Add_to_Cart")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-active">
                        <i class="fa fa-users" aria-hidden="true"></i> <?php echo e(Vars::getVar("Review_Orders")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <i class="fa fa-lock"></i> <?php echo e(Vars::getVar("Secure_checkout")); ?>

                    </div>
                </div>
                <!-- end directory -->
                <div class="row">
                    <div class="col-md-12 review-orders-header"><i class="fa fa-shopping-cart" aria-hidden="true"></i> <?php echo e(Vars::getVar("Review_Your_Orders")); ?></div>
                </div>
                <div class="row">
                    <div class="col-md-12 review-orders-table">
                        <div class="row review-orders-table-items review-orders-gray">
                            <div class="col-md-9">
                                <?php echo e(Vars::getVar('Subtotal')); ?>

                            </div>
                            <div class="col-md-3"><?php echo e(sprintf('%.2f',$total)); ?> <?php echo e(Vars::getVar("$")); ?></div>
                        </div>
                        <div class="row review-orders-table-items review-orders-white">
                            <div class="col-md-9">
                                <?php echo e(Vars::getVar('Deposit')); ?>

                            </div>
                            <div class="col-md-3"><?php echo e(sprintf('%.2f',$total*$percent/100)); ?></div>
                        </div>
                        <div class="row review-orders-table-items review-orders-blue">
                            <div class="col-md-9">
                                <i class="fa fa-money" aria-hidden="true"></i> <?php echo e(Vars::getVar('Total')); ?>

                            </div>
                            <div class="col-md-3"><?php echo e(sprintf('%.2f',$total)); ?> <?php echo e(Vars::getVar("$")); ?></div>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-top: 10px;">
                    <div class="row" style="margin-bottom: 5px;">
                        <div class="col-md-12" style="padding-left: 0px; padding-right: 0px;">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-primary btn-block" style="font-size: 17px;"><i class="fa fa-arrow-left" aria-hidden="true"></i> <?php echo e(Vars::getVar("Continue_shopping")); ?></a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 text-right" style="padding-left: 0px; padding-right: 0px;">
                            <a href="<?php echo e(route('Web.checkout')); ?>" class="btn btn-success btn-block" style="font-size: 17px;"><i class="fa fa-check" aria-hidden="true"></i> <?php echo e(Vars::getVar("Proceed_to_Checkout")); ?></a>
                        </div>
                    </div>
                    <?php if(isset($items)): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php if(isset($item['dist_from'])): ?>
                    <div class="row review-items">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>
                                    Transfer From <?php echo e($item['dist_from']); ?> To <?php echo e($item['dist_to']); ?>

                                </h1>
                            </div>
                        </div>
                        <div class="row review-all-details">
                            <div class="col-md-4">

                                <img src="<?php echo e(asset('images/Airport-Transfer.jpg')); ?>" style="width: 100%;" alt="">
                            </div>
                            <div class="col-md-5 review-item-details">
                                <div class="col-md-12">
                                    <?php echo e(vars::getVar("Date")); ?>: <?php echo e($item['date']); ?>

                                </div>

                                <div class="col-md-12">
                                    <?php echo e(vars::getVar("Transfer_Type")); ?>:<?php echo e(vars::getVar($item['transfer_type'])); ?>

                                </div>
                                <div class="col-md-12">
                                    <?php if($item['transfer_times']==2): ?>
                                    <?php echo e(vars::getVar("Go/Return")); ?>

                                    <?php else: ?>
                                    <?php echo e(vars::getVar("One_Way")); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12">
                                    <?php echo e(vars::getVar("Pax")); ?>: <?php echo e($item['pax']); ?>

                                </div>
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('remove.from.cart',['id'=>$key])); ?>" id="remove-cart-item"><i class="fa fa-trash" aria-hidden="true"></i> <?php echo e(Vars::getVar('remove')); ?></a>
                                </div>
                            </div>
                            <div class="col-md-3 review-item-price">
                                <?php echo e(sprintf('%.2f',$item['price'])); ?> <span><?php echo e(Vars::getVar("$")); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- tours items review -->
                    <div class="row review-items">
                        <div class="row">
                            <div class="col-md-12">
                                <h1>
                                    <?php echo e(App\MyModels\Admin\Item::find($key)->title); ?>

                                </h1>
                            </div>
                        </div>
                        <div class="row review-all-details">
                            <div class="col-md-4">

                                <img src="<?php echo e(asset('images/items/thumb/'.App\MyModels\Admin\Item::find($key)->img)); ?>" style="width: 100%;" alt="<?php echo e(App\MyModels\Admin\Item::find($key)->title); ?>">
                            </div>
                            <div class="col-md-5 review-item-details">
                                <div class="col-md-12">
                                    <?php echo e(Vars::getVar('Travel_date')); ?>: <?php echo e($item['date']); ?>

                                </div>
                                <div class="col-md-12">
                                    <?php echo e(Vars::getVar('Number_of_Adult')); ?>: <?php echo e($item['st_no']); ?>

                                </div>
                                <div class="col-md-12">
                                    <?php echo e(Vars::getVar('Number_of_Child')); ?>: <?php echo e($item['sec_no']); ?>

                                </div>
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('remove.from.cart',['id'=>$key])); ?>" id="remove-cart-item"><i class="fa fa-trash" aria-hidden="true"></i> <?php echo e(Vars::getVar('remove')); ?></a>
                                </div>
                            </div>
                            <div class="col-md-3 review-item-price">
                                <?php echo e(sprintf('%.2f',$item['price'])); ?> <span><?php echo e(Vars::getVar("$")); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.TrnasferForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="row">
                    <div class="col-md-12 youtube-holder">
                        <iframe id="youtube"  height="315" src="https://www.youtube.com/embed/jnfwoGw3fnU" frameborder="0" allowfullscreen></iframe>
                    </div>


                </div>



            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("More_Things_to_Do_in_Sharm_el_Sheikh")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Seccategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><span><a href="<?php echo e(route('cities.show',['city'=>urlencode($Seccategory->name),'id'=>$Seccategory->id])); ?>"><?php echo e($Seccategory->title); ?></a></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("Top_Sharm_el_Sheikh_Attractions")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php $__currentLoopData = $LinkCategory->items->where('recommended',"=",1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li><span><a href="<?php echo e(route('tour.show',['city'=>urlencode($LinkCategory->name),'tour'=>urlencode($LinkItems->name),'id'=>$LinkItems->id])); ?>"><?php echo e($LinkItems->title); ?></a></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>

<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
$(function() {
//Initialize Select2 Elements
    $(".select2").select2();
    $('#reservation').daterangepicker({
        startDate: new Date(),
        minDate: new Date()

    });

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>