<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Password_reset')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <h1 class="sent-email-success"><?php echo e(translate('Reset_password_link_has_been_sent_to_your_email_successfully')); ?></h1>
            <h1 class="main-title"><?php echo e(translate('Top_Tours_&_Activities')); ?></h1>
            <?php $__currentLoopData = topTours()->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row items-container">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        $link = route('home.item.show', [
                            'category' => urlencodeLink($item->category->name),
                            'name' => urlencodeLink($item->name),
                            'id' => $item->id]);
                        ?>
                        <div class="col-md-4">
                            <div class="item-container">
                                <?php if($item->offer): ?>
                                    <div class="hot-offers-label"></div>
                                <?php endif; ?>

                                <div class="row item-container-footer">
                                    <div class="col-md-6 col-xs-6 col-sm-6 item-footer-price">
                                        <?php if(isset($item->price)): ?>
                                            <?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                        <?php endif; ?>
                                        <span><?php echo e(translate('$')); ?></span>
                                    </div>
                                    <div class="col-md-6 col-xs-6 col-sm-6 item-footer-basket">
                                        <a href="<?php echo e($link); ?>">
                                            <?php echo e(translate('Add_to_basket')); ?> <i class="fa fa-cart-plus"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="item-container-img">
                                    <a href="<?php echo e($link); ?>">
                                        <img src="<?php echo e(asset('images/items/thumbMd/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>">
                                    </a>
                                </div>
                                <div class="item-container-text">
                                    <h2><?php echo e($item->name); ?></h2>
                                    <span>
                                    <?php echo e(str_limit($item->intro,90,'...')); ?>

                                        <a href="<?php echo e($link); ?>">Read More</a>
                                </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>