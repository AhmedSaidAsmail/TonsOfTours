<?php $__env->startSection('title','Items Panel | Update'); ?>
<?php $__env->startSection('Extra_Css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/timepicker/bootstrap-timepicker.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <?php if(Session::has('errorMsg')): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h4><i class="icon fa fa-ban"></i> <?php echo e(Session('errorMsg')); ?> </h4>
        ..<a href="#" id="errorDetails">Details</a>
        <?php echo (Session::has('errorDetails'))?'<p id="ErrorMsgDetails">'.Session('errorDetails').'</p>':''; ?>

    </div>
    <?php endif; ?>
    <!-- Directory&Header -->
    <section class="content-header">
        <h1>Items <small>Items Update</small> </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
            <li><a href="#">Update Items : <?php echo e($Item->name); ?></a></li>
        </ol>
    </section>
    <!-- end Directory&Header -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <!-- box -->
                <div class="box">
                    <div class="box-header with-border">
                        <div class="form-group">
                            <button type="submit" class="btn btn-default form-control" id="addNew"><i class="fa fa-paw"></i> Update: <a href="#"><?php echo e($Item->name); ?></a></button>
                        </div>
                    </div>
                    <div id="basicToggle">
                        <form method="post" action="<?php echo e(route('Items.update',['id'=>$Item->id])); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="_method" value="PUT">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Category Name:</label>
                                            <select class="form-control" name="sort_id">
                                                <option value="">Select  Category</option>
                                                <?php $__currentLoopData = App\MyModels\Admin\Sort::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo ($category->id==$Item->sort_id)?'selected="selected"':''; ?>><?php echo e($category->name); ?> -- <?php echo e($category->basicsort->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Item Name:</label>
                                            <input class="form-control" value="<?php echo e($Item->name); ?>" name="name" placeholder="Main category Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Item Title:</label>
                                            <input class="form-control" value="<?php echo e($Item->title); ?>" name="title" placeholder="Main category Title" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control" name="status">
                                                <option value="1" >Show</option>
                                                <option value="0" <?php echo (! $Item->status)?'selected="selected"':''; ?>>Hidden</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label>Home Shortcut</label>

                                            <select class="form-control" name="recommended">
                                                <option value="1">Show</option>
                                                <option value="0" <?php echo (! $Item->recommended)?'selected="selected"':''; ?>>Hidden</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group <?php echo e($errors->has('arrangement')?'has-error':''); ?>">
                                            <label>Arrangment</label>
                                            <input  value="<?php echo e($Item->arrangement); ?>" name="arrangement" class="form-control">
                                            <?php if($errors->has('arrangement')): ?>
                                            <span class="help-block">The Arrangment has to be Integer</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group <?php echo e($errors->has('img')?'has-error':''); ?>">
                                            <label>Image</label>
                                            <input type="file" class="form-control" name="img">
                                            <?php if($errors->has('img')): ?>
                                            <span class="help-block">It has to be an Image File</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Keywords:</label>
                                            <input class="form-control" value="<?php echo e($Item->keywords); ?>" name="keywords" placeholder="-- Keywords --" >
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <input class="form-control" value="<?php echo e($Item->description); ?>" name="description" placeholder="-- Description --" >
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label>Intro</label>
                                            <textarea class="form-control" name="intro"><?php echo e($Item->intro); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group"> <input type="submit" class="btn btn-primary" value="Edit Main Category"></div>
                                <div class="form-group"> </div>
                            </div>
                        </form>
                    </div>
                </div>




                <!-- Item private prices -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-money"></i> <a href="#">Item Private Prices</a> Table</h3>
                    </div>
                    <div class="box-body">

                        <table class="table table-hover">
                            <tr>
                                <th>Sort</th>
                                <th>1 Pax</th>
                                <th>2 Pax</th>
                                <th>3 Pax</th>
                                <th>4-9 Pax</th>
                                <th>10-18 Pax</th>
                                <th>18-45 Pax</th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $Item->privates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privates): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <tr>
                                <td><?php echo e($privates->sort); ?></td>
                                <td><?php echo e($privates->pax_1); ?></td>
                                <td><?php echo e($privates->pax_2); ?></td>
                                <td><?php echo e($privates->pax_3); ?></td>
                                <td><?php echo e($privates->pax_4); ?></td>
                                <td><?php echo e($privates->pax_10); ?></td>
                                <td><?php echo e($privates->pax_18); ?></td>
                                <td>
                                    <form method="post" action="<?php echo e(route('Private.destroy',['itemID'=>$Item->id,'id'=>$privates->id])); ?>">
                                        <a href="<?php echo e(route('Private.edit',['itemID'=>$Item->id,'id'=>$privates->id])); ?>"class="btn btn-sm btn-info"><i class="fa fa-edit"></i> Edit</a>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </table>

                        <form method="post" action="<?php echo e(route('Private.store',['itemId'=>$Item->id])); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="item_id" value="<?php echo e($Item->id); ?>">
                            <div class="row">
                                <div class="col-md-3"><input class="form-control" type="text" name="sort" placeholder="Price Sort like Adult"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_1" placeholder="1Pax"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_2" placeholder="2Pax"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_3" placeholder="3Pax"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_4" placeholder="4-9Pax"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_10" placeholder="8-18Pax"></div>
                                <div class="col-md-1"><input class="form-control" type="number" name="pax_18" placeholder="18-45Pax"></div>
                                <div class="col-md-2"><button class="btn btn-success">Add Private Price</button></div>

                            </div>
                        </form>

                    </div>
                </div>
                <!-- Item private prices End -->






                <!-- Item Price -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><i class="fa fa-money"></i> <a href="#">Item Prices</a> Table</h3>
                    </div>
                    <div class="box-body">
                        <?php if(count($Item->price)>0): ?>
                        <table class="table table-hover">
                            <tr>
                                <th>First Price Name</th>
                                <th>First Price</th>
                                <th>Second Price Name</th>
                                <th>Second price</th>
                                <th></th>
                            </tr>
                            <tr>
                                <td><?php echo e($Item->price->st_name); ?></td>
                                <td><?php echo e($Item->price->st_price); ?></td>
                                <td><?php echo e($Item->price->sec_name); ?></td>
                                <td><?php echo e($Item->price->sec_price); ?></td>
                                <td>
                                    <form method="post" action="<?php echo e(route('Price.destroy',['itemID'=>$Item->id,'id'=>$Item->price->id])); ?>">
                                        <a href="<?php echo e(route('Price.edit',['itemID'=>$Item->id,'id'=>$Item->price->id])); ?>"class="btn btn-sm btn-info"><i class="fa fa-edit"></i> Edit</a>
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        </table>
                        <?php else: ?>
                        <form method="post" action="<?php echo e(route('Price.store',['itemId'=>$Item->id])); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="hidden" name="item_id" value="<?php echo e($Item->id); ?>">
                            <div class="row">
                                <div class="col-md-3"><input class="form-control" type="text" name="st_name" placeholder="First Price Name"></div>
                                <div class="col-md-2"><input class="form-control" type="text" name="st_price" placeholder="First Price"></div>
                                <div class="col-md-3"><input class="form-control" type="text" name="sec_name" placeholder="Second Price Name"></div>
                                <div class="col-md-2"><input class="form-control" type="text" name="sec_price" placeholder="Second Price"></div>
                                <div class="col-md-2"><button class="btn btn-success">Add New Price</button></div>

                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Item Price End -->
                <!-- Item Exploration  -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-clock-o"></i> Exploration </a></h3>
                    </div>
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select class="form-control" name="galleryAction" id="galleryNav">
                                        <option value="">Select an Action</option>
                                        <option value="<?php echo e(route('Exploration.create',['itemID'=>$Item->id])); ?>">Add New</option>
                                        <option value="<?php echo e(route('Exploration.index',['itenID'=>$Item->id])); ?>">Exploration List</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Item Exploration End -->


                <div>
                    <form action="<?php echo e(route('Information.create',['itemID'=>$Item->id])); ?>" method="get">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Add New Details To This Items</label>
                                    <select name="modelName" class="form-control" id="detailsNavigatore">
                                        <option value="">Select Details to Add</option>
                                        <option value="inclusion">Inclusions</option>
                                        <option value="exclusion">Exclusions</option>
                                        <option value="additional">Additional Information </option>
                                        <option value="dresse">Dresses</option>
                                        <option value="note">Notes</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <!-- Inclusions -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Inclusions Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Inclusions Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->inclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($inclusion->txt); ?></td>
                                        <td><a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'Information'=>$inclusion->id,'modelName'=>'inclusion'])); ?>" class="btn btn-xs btn-warning">Edit</a></td>
                                        <td><a href="<?php echo e(route('Information.show',['item'=>$Item->id,'Information'=>$inclusion->id,'modelName'=>'inclusion'])); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Inclusions-->
                        <!-- Additional Information -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Additional Information Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Information Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->additional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $additional): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($additional->txt); ?></td>
                                        <td><a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'rowID'=>$additional->id,'modelName'=>'additional'])); ?>" class="btn btn-xs btn-warning">Edit</a></td>
                                        <td><a href="<?php echo e(route('Information.show',['item'=>$Item->id,'rowID'=>$additional->id,'modelName'=>'additional'])); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Additional Information-->
                        <!-- Dresses -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Dresses Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Dresses Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->dresse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dresse): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($dresse->txt); ?></td>
                                        <td><a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'rowID'=>$dresse->id,'modelName'=>'dresse'])); ?>" class="btn btn-xs btn-warning">Edit</a></td>
                                        <td><a href="<?php echo e(route('Information.show',['item'=>$Item->id,'rowID'=>$dresse->id,'modelName'=>'dresse'])); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Dresses-->

                    </div>
                    <div class="col-md-6">
                        <!-- Inclusions -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Exclusions Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Exclusions Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->exclusion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclusion): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($exclusion->txt); ?></td>
                                        <td><a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'Information'=>$exclusion->id,'modelName'=>'exclusion'])); ?>" class="btn btn-xs btn-warning">Edit</a></td>
                                        <td><a href="<?php echo e(route('Information.show',['item'=>$Item->id,'Information'=>$exclusion->id,'modelName'=>'exclusion'])); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Inclusions-->
                        <!-- Notes -->
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Notes Table</h3>
                            </div>
                            <div class="box-body no-padding">
                                <table class="table table-striped">
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th>Notes Text</th>
                                        <th>Edit</th>
                                        <th style="width: 40px">Delete</th>
                                    </tr>
                                    <?php $oredr = 1 ?>
                                    <?php $__currentLoopData = $Item->note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e($oredr); ?></td>
                                        <td><?php echo e($note->txt); ?></td>
                                        <td><a href="<?php echo e(route('Information.edit',['item'=>$Item->id,'rowID'=>$note->id,'modelName'=>'note'])); ?>" class="btn btn-xs btn-warning">Edit</a></td>
                                        <td><a href="<?php echo e(route('Information.show',['item'=>$Item->id,'rowID'=>$note->id,'modelName'=>'note'])); ?>"><i class="fa fa-trash"></i></a></td>
                                    </tr>
                                    <?php $oredr++ ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </table>
                            </div>
                        </div>
                        <!-- end Notes-->
                        <!-- Item Gallery -->
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title"><a href="#"><i class="fa fa-android"></i> Gallery </a></h3>
                            </div>
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <select class="form-control" name="galleryAction" id="galleryNav">
                                                <option value="">Select an Action</option>
                                                <option value="<?php echo e(route('Gallery.create',['itemID'=>$Item->id])); ?>">Upload New Images</option>
                                                <option value="<?php echo e(route('Gallery.index',['itenID'=>$Item->id])); ?>">Gallery List</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Item Gallery End -->

                    </div>

                </div>


                <!-- Items Details -->
                <div class="box">
                    <div class="box-header with-border">
                        <h3 class="box-title"><a href="#"><i class="fa fa-th"></i> Item Details</a> Table</h3>
                    </div>
                    <div class="box-body">
                        <?php if(count($Item->detail)>0): ?>
                        <div class="row">
                            <div class="col-md-2"><span class="h4">Started At</span></div>
                            <div class="col-md-1"><?php echo e($Item->detail->started_at); ?></div>
                            <div class="col-md-2"><span class="h4">Ended At</span></div>
                            <div class="col-md-1"><?php echo e($Item->detail->ended_at); ?></div>

                            <div class="col-md-2">
                                <span class="h4"> Availability</span>
                            </div>
                            <div class="col-md-2">
                                <?php if(isset($Item->detail->availability)): ?>
                                <?php $__currentLoopData = unserialize($Item->detail->availability); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <span class="label label-default"><?php echo e($day); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <a href="<?php echo e(route('Detail.edit',['itemID'=>$Item->id,'detail'=>$Item->detail->id])); ?>" class="btn btn-info"><i class="fa fa-hand-pointer-o"></i> Update Details</a>
                                </div>
                            </div>
                        </div>
                        <?php else: ?>
                        <form method="post" action="<?php echo e(route('Detail.store',['itemID'=>$Item->id])); ?>">
                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label>Started At:</label>
                                            <div class="input-group">
                                                <input type="text" name="started_at" class="form-control timepicker">
                                                <div class="input-group-addon"> <i class="fa fa-clock-o"></i> </div>
                                            </div>
                                            <!-- /.input group -->
                                        </div>
                                        <!-- /.form group -->
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="bootstrap-timepicker">
                                        <div class="form-group">
                                            <label>Ended At:</label>
                                            <div class="input-group">
                                                <input type="text" name="ended_at" class="form-control timepicker">
                                                <div class="input-group-addon"> <i class="fa fa-clock-o"></i> </div>
                                            </div>
                                            <!-- /.input group -->
                                        </div>
                                        <!-- /.form group -->
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Availability</label>
                                        <select name="availability[]" class="form-control select2" multiple="multiple" data-placeholder="Select a Day">
                                            <option>Saturday</option>
                                            <option>Sunday</option>
                                            <option>Monday</option>
                                            <option>Tuesday</option>
                                            <option>Thursday</option>
                                            <option>Wednesday</option>
                                            <option>Friday</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label></label>
                                        <button class="btn btn-primary form-control"><i class="fa fa-paw"></i> Add Details</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- Items Details End -->





            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- end content -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
<script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('adminlte/plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<script>
$(function() {
    $(".select2").select2();
    $(".timepicker").timepicker({
        showInputs: false,
        showMeridian: false
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts.Layout_Basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>