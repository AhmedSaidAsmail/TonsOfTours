<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Wish_List')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="wish-list-container">
                <h1 class="main-wish-list-title"><?php echo e(translate('My_Wish_list')); ?></h1>
                <span class="wish-list-count"><i class="far fa-heart"></i> <?php echo e(count($wishLists)); ?></span>
                <?php $__currentLoopData = $wishLists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishList): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php
                    $link = route('home.item.show', [
                        'category' => urlencodeLink($wishList->item->category->name),
                        'name' => urlencodeLink($wishList->item->name),
                        'id' => $wishList->item->id]);
                    ?>
                    <div class="row wish-list-holder">
                        <a href="<?php echo e(route('wish-list.destroy',['id'=>$wishList->id])); ?>" class="wish-list-remove">
                            <i class="fas fa-times"></i>
                        </a>
                        <div class="wish-list-price">
                            <?php echo e(translate('From')); ?>

                            <span><?php echo e(translate('$')); ?> <?php echo e(sprintf('%.2f',$wishList->item->price->st_price)); ?></span>
                        </div>
                        <div class="col-md-3 wish-list-img">
                            <img src="<?php echo e(asset('images/items/thumbMd/'.$wishList->item->img)); ?>"
                                 alt="<?php echo e($wishList->item->title); ?>" class="aspect-img">
                        </div>
                        <div class="col-md-9 wish-list-details">
                            <h1><?php echo e($wishList->item->title); ?></h1>
                            <?php echo e(str_limit($wishList->item->intro,150,'...')); ?>

                            <a href="<?php echo e($link); ?>"><?php echo e(translate('read_more')); ?></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>