<section class="customer-login">
    <div class="login-area">
        <div class="login-container animated bounceInDown">
            <!-- bounceInDown bounceOutUp -->
            <i class="fa fa-times-circle" id="close-login"></i>
            <h2>Log in to A2ZTravel</h2>
            <span class="login-header-span">
            <?php echo e(translate('Log_in_to_add_things_to_your_Wish_List_and_access_your_bookings_from_any_device.')); ?>

            </span>
            <a href="<?php echo e(route('customer.facebook.redirect')); ?>" class="btn btn-block btn-social btn-facebook">
                <i class="fa fa-facebook"></i> <?php echo e(translate('Log_in_with_Facebook')); ?>

            </a>
            <a class="btn btn-block btn-social btn-default">
                <i class="fa fa-google"></i> <?php echo e(translate('Log_in_with_Google')); ?>

            </a>
            <span class="login-or">or</span>
            <form method="post" action="<?php echo e(route('customer.login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <input type="text" class="form-control" name="email" value="" placeholder="Email address">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" value="" placeholder="Password">
                </div>
                <div class="row">
                    <div class="col-md-6 col-xs-6">
                        <div class="checkbox icheck">
                            <label>
                                <input type="checkbox" name="remember"> <?php echo e(translate('Remember_Me')); ?>

                            </label>
                        </div>
                    </div>
                    <div class="col-md-6 col-xs-6 text-right">
                        <a href="<?php echo e(route('customer.password.reset')); ?>" class="reset-password">
                            <?php echo e(translate('Forgot_your_password?')); ?>

                        </a>
                    </div>
                </div>
                <button class="btn btn-success btn-block sign-up"><?php echo e(translate('Log_in')); ?></button>
            </form>
            <div class="sign-up-section">
                <?php echo e(translate('New_here?')); ?> <a href="<?php echo e(route('customer.register')); ?>"><?php echo e(translate('Sign_up_here!')); ?></a>
            </div>


        </div>
    </div>
</section>
<?php $__env->startSection('_extra_js'); ?>
    @parent
    <script>
        $(function () {
            let login = $("div.login-area");
            $("a#login").on('click', function (event) {
                event.preventDefault();
                open_closed_login();
            });
            $("i#close-login").on('click', function () {
                open_closed_login();
            });

            function open_closed_login() {
                if (login.is(':visible')) {
                    login.fadeOut();
                    return true;
                }
                login.show();

            }
        });
    </script>
<?php $__env->stopSection(); ?>