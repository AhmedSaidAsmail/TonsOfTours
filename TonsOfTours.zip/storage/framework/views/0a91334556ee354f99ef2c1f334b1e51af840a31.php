<?php $__env->startSection('meta_tags'); ?>
    <meta name="keywords" content="<?php echo e($mainCategory->keywords); ?>"/>
    <meta name="description" content="<?php echo e($mainCategory->description); ?>"/>
    <title><?php echo e($mainCategory->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <img class="aspect-img" src="<?php echo e(asset('images/mainCategories/'.$mainCategory->img)); ?>"
             alt="<?php echo e($mainCategory->title); ?>">
        <div class="insider-header-contains">
            <div class="container">
                <ul class="list-inline dir">
                    <li><?php echo e(translate('WHERE_TO_GO')); ?></li>
                    <li><?php echo e($mainCategory->title); ?></li>
                </ul>
                <h1><?php echo e($mainCategory->title); ?></h1>
            </div>
        </div>

    </div>
    <?php echo $__env->make('frontEnd.layouts._headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <h1 class="main-title"><?php echo e(translate('Top_Tours_&_Activities')); ?></h1>
            <div class="row items-container">
                <?php $__currentLoopData = $topItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php
                    $link = route('home.item.show', [
                        'category' => urlencodeLink($item->category->name),
                        'name' => urlencodeLink($item->name),
                        'id' => $item->id]);
                    ?>
                    <div class="col-md-4">
                        <div class="item-container">
                            <?php if($item->offer): ?>
                                <div class="hot-offers-label"></div>
                            <?php endif; ?>

                            <div class="row item-container-footer">
                                <div class="col-md-6 col-xs-6 col-sm-6 item-footer-price">
                                    <?php if(isset($item->price)): ?>
                                        <?php echo e(sprintf('%.2f',$item->cheapestPrise()->st_price)); ?>

                                    <?php endif; ?>
                                    <span><?php echo e(payment()->currency_symbol); ?></span>
                                </div>
                                <div class="col-md-6 col-xs-6 col-sm-6 item-footer-basket">
                                    <a href="<?php echo e($link); ?>">
                                        <?php echo e(translate('Add_to_basket')); ?> <i class="fa fa-cart-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="item-container-img">
                                <a href="<?php echo e($link); ?>">
                                    <img src="<?php echo e(asset('images/items/thumbMd/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>">
                                </a>
                            </div>
                            <div class="item-container-text">
                                <h2><?php echo e($item->name); ?></h2>
                                <span>
                                    <?php echo e(str_limit($item->intro,90,'...')); ?>

                                    <a href="<?php echo e($link); ?>">Read More</a>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <h1 class="main-title"><?php echo e($mainCategory->title); ?> <?php echo e(translate('Packages')); ?></h1>
            <?php
            $slice_1 = $mainCategory->categories->slice(0, 2);
            $slice_2 = $mainCategory->categories->slice(2);
            ?>
            <div class="row items-container">
                <?php $__currentLoopData = $slice_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('home.category.show',['city'=>urlencodeLink($category->name),'id'=>$category->id])); ?>">
                            <div class="item-holder-first">
                                <img class="aspect-img" src="<?php echo e(asset('images/categories/thumbMd/'.$category->img)); ?>"
                                     alt="<?php echo e($category->title); ?>">
                            </div>
                            <h2 class="item-title"><?php echo e($category->title); ?></h2>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <?php $__currentLoopData = $slice_2->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row items-container">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-md-3">
                            <a href="<?php echo e(route('home.category.show',['city'=>urlencodeLink($category->name),'id'=>$category->id])); ?>">
                                <div class="item-holder-second">
                                    <img class="aspect-img" src="<?php echo e(asset('images/categories/thumbMd/'.$category->img)); ?>"
                                         alt="<?php echo e($category->title); ?>">
                                </div>
                                <h2 class="item-title"><?php echo e($category->title); ?></h2>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>