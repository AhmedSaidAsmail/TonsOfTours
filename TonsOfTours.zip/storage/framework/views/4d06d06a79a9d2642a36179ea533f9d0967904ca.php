<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Settings')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="row customer-setting-form">
                <div class="col-md-3 setting-links-holder">
                    <ul class="list-group list-group-sp">
                        <li class="list-group-item">
                            <a href="<?php echo e(route('customer.booking')); ?>">
                                <i class="fas fa-plane-departure"></i> <?php echo e(translate('Bookings')); ?>

                            </a>
                        </li>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('customer.setting')); ?>">
                                <i class="fa fa-user"></i> <?php echo e(translate('Profile')); ?>

                            </a>
                        </li>
                        <li class="list-group-item active">
                            <a href="<?php echo e(route('customer.password')); ?>">
                                <i class="fa fa-lock"></i> <?php echo e(translate('Password')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-9 customer-setting-details">
                    <h1><?php echo e(translate('Password')); ?></h1>
                    <form action="<?php echo e(route('customer.password')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Password</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <input type="password" class="form-control" name="password" value=""
                                               autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Confirm Password</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-at"></i>
                                        </div>
                                        <input type="password" class="form-control" name="password_confirmation"
                                               value="" autocomplete="off" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success btn-block">
                                    <i class="fas fa-save"></i> Update Password
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>