<div id="general" class="tab-pane fade in active">
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Category</label>
                <select name="sort_id" class="form-control select-options" style="border-radius: 0px;" required>
                    <option value="">Select a Category</option>
                    <?php $__currentLoopData = $sorts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sort): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        if (!is_null($item) && $sort->id == $item->sort_id) {
                            $selected = "selected";
                        } else {
                            $selected = null;
                        }
                        ?>
                        <option value="<?php echo e($sort->id); ?>"<?php echo e($selected); ?>><?php echo $sort->parent?$sort->parent->name." > ":null; ?><?php echo e($sort->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Name</label>
                <input name="name" value="<?php echo e(getValue("name",$item)); ?>" class="form-control" required>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Title</label>
                <input name="title" value="<?php echo e(getValue("title",$item)); ?>" class="form-control" required>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Meta Keywords</label>
                <input name="meta_keywords" value="<?php echo e(getValue("meta_keywords",$item)); ?>" class="form-control" >

                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Meta Description</label>
                <input name="meta_description" value="<?php echo e(getValue("meta_description",$item)); ?>" class="form-control" >
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Meta Title</label>
                <input name="meta_title" value="<?php echo e(getValue("meta_title",$item)); ?>" class="form-control" >
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Duration</label>
                <input name="duration" value="<?php echo e(getValue("duration",$item)); ?>" class="form-control">

                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Type</label>
                <select name="type" class="form-control">
                    <option value="">Select Type</option>
                    <option value="group_tour"<?php echo !is_null($item) && $item->type=="group_tour"?" selected":null; ?>>Group Tour</option>
                    <option value="private_tour"<?php echo !is_null($item) && $item->type=="private_tour"?" selected":null; ?>>Private Tour</option>
                    <option value="small_group_tour"<?php echo !is_null($item) && $item->type=="small_group_tour"?" selected":null; ?>>Small Group Tour</option>
                    <option value="nile_cruise_tours"<?php echo !is_null($item) && $item->type=="nile_cruise_tours"?" selected":null; ?>>Nile Cruise Tours</option>
                </select>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Run</label>
                <input name="run" value="<?php echo e(getValue("run",$item)); ?>" class="form-control" placeholder="Eg: Everyday">
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-md-4">
            <div class="form-group">
                <label>Pick-up Time</label>
                <input name="pick_up" value="<?php echo e(getValue("pick_up",$item)); ?>" class="form-control" placeholder="Eg:Around 07:00 AM">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Schedule</label>
                <input name="schedule" value="<?php echo e(getValue("schedule",$item)); ?>" class="form-control" placeholder="Eg: Every Monday from Aswan & Thursday from Luxor">
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-group">
                <label>Intro Image</label>
                <input type="file" name="img" class="form-control">
            </div>
        </div>
    </div>
</div>