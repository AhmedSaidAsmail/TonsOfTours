<?php $__env->startSection('title','Payment Settings'); ?>
<?php $__env->startSection('Extra_Css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1> Payment
                <small>Payment Details</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel </a></li>
                <li><a href="#">Payment</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <span>Default Deposit Percentage</span>
                        </div>
                        <div class="box-body">
                            <?php if(!is_null($payment_setting)): ?>
                                <form method="post" id="depositDelete"
                                      action="<?php echo e(route('setting.payment.payment-setting.destroy',['id'=>$payment_setting->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE">
                                </form>
                                <form method="post"
                                      action="<?php echo e(route('setting.payment.payment-setting.update',['id'=>$payment_setting->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="PUT">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Currency</label>
                                                <select name="currency" class="form-control">
                                                    <option value="">Select Currency</option>
                                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sympole=>$currency): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <option value="<?php echo e($sympole); ?>"<?php echo $payment_setting->currency_symbol==$sympole?"selected":null; ?>><?php echo e($currency); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Percentage</label>
                                                <input class="form-control" name="default_percentage"
                                                       value="<?php echo e($payment_setting->default_percentage); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <ul class="list-inline">
                                                <li>
                                                    <button class="btn btn-success">
                                                        <i class="fa fa-save"></i>
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="btn btn-danger" form="depositDelete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <form method="post" action="<?php echo e(route('setting.payment.payment-setting.store')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Currency</label>
                                                <select name="currency" class="form-control">
                                                    <option value="">Select Currency</option>
                                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sympole=>$currency): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <option value="<?php echo e($sympole); ?>"><?php echo e($currency); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Percentage</label>
                                                <input class="form-control" name="default_percentage" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <button class="btn btn-success"><i class="fa fa-save"></i></button>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="box">
                        <div class="box-header with-border">
                            <span>Paypal</span>
                        </div>
                        <div class="box-body">
                            <?php if(!is_null($paypal)): ?>
                                <form method="post" id="paypalDelete"
                                      action="<?php echo e(route('setting.payment.paypal.destroy',['id'=>$paypal->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE">
                                </form>
                                <form method="post"
                                      action="<?php echo e(route('setting.payment.paypal.update',['id'=>$paypal->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="PUT">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">Sandbox</label>
                                                <input type="checkbox" name="sandbox"
                                                       value="1" <?php echo $paypal->sandbox?'checked':null; ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Client ID</label>
                                                <input class="form-control" name="client_id"
                                                       value="<?php echo e($paypal->client_id); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Secret</label>
                                                <input class="form-control" name="secret" value="<?php echo e($paypal->secret); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input class="form-control" name="description"
                                                       value="<?php echo e($paypal->description); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <ul class="list-inline">
                                                <li>
                                                    <button class="btn btn-success">
                                                        <i class="fa fa-save"></i> Update
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="btn btn-danger" form="paypalDelete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </form>
                            <?php else: ?>
                                <form method="post"
                                      action="<?php echo e(route('setting.payment.paypal.store')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">Sandbox</label>
                                                <input type="checkbox" name="sandbox"
                                                       value="1">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Client ID</label>
                                                <input class="form-control" name="client_id" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Secret</label>
                                                <input class="form-control" name="secret" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Description</label>
                                                <input class="form-control" name="description" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <ul class="list-inline">
                                                <li>
                                                    <button class="btn btn-success">
                                                        <i class="fa fa-save"></i> Save
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="box">
                        <div class="box-header with-border">
                            <span>2 Checkout</span>
                        </div>
                        <div class="box-body">
                            <?php if(!is_null($two_checkout)): ?>
                                <form method="post" id="checkoutDelete"
                                      action="<?php echo e(route('setting.payment.two-checkout.destroy',['id'=>$two_checkout->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="DELETE">
                                </form>
                                <form method="post"
                                      action="<?php echo e(route('setting.payment.two-checkout.update',['id'=>$two_checkout->id])); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="PUT">
                                    <div class="row">
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">Sandbox</label>
                                                <input type="checkbox" name="sandbox"
                                                       value="1" <?php echo $two_checkout->sandbox?'checked':null; ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">SSL</label>
                                                <input type="checkbox" name="ssl"
                                                       value="1" <?php echo $two_checkout->ssl?'checked':null; ?>>
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Partner ID</label>
                                                <input class="form-control" name="partner_id"
                                                       value="<?php echo e($two_checkout->partner_id); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Public Key</label>
                                                <input class="form-control" name="public_key"
                                                       value="<?php echo e($two_checkout->public_key); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Private Key</label>
                                                <input class="form-control" name="private_key"
                                                       value="<?php echo e($two_checkout->private_key); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <ul class="list-inline">
                                                <li>
                                                    <button class="btn btn-success">
                                                        <i class="fa fa-save"></i> Update
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="btn btn-danger" form="checkoutDelete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <form method="post"
                                      action="<?php echo e(route('setting.payment.two-checkout.store')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="row">
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">Sandbox</label>
                                                <input type="checkbox" name="sandbox"
                                                       value="1">
                                            </div>
                                        </div>
                                        <div class="col-md-1">
                                            <div class="form-group">
                                                <label style="display: block">SSL</label>
                                                <input type="checkbox" name="ssl"
                                                       value="1">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Partner ID</label>
                                                <input class="form-control" name="partner_id"
                                                       value="">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Public Key</label>
                                                <input class="form-control" name="public_key" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <div class="form-group">
                                                <label>Private Key</label>
                                                <input class="form-control" name="private_key" value="">
                                            </div>
                                        </div>
                                        <div class="col-md-2" style="padding-top: 25px;">
                                            <ul class="list-inline">
                                                <li>
                                                    <button class="btn btn-success">
                                                        <i class="fa fa-save"></i> Save
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>