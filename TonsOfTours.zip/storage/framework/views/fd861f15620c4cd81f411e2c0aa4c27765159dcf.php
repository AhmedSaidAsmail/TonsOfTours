<?php if(payment()->hasTwoCheckout): ?>
    <section class="checkout-form-section" id="credit-section">
        <h3><?php echo e(translate('Payment_Details')); ?></h3>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Cardholder Name*</label>
                    <input class="form-control" value="Ahmed Said Asmail" name="credit[name]" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>Credit Card Number*</label>
                    <input class="form-control" name="credit[cc_no]" value="4000000000000002" id="ccNo" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label>Expiration Date*</label>
                    <select name="credit[cc_expire_month]" class="form-control" id="expMonth"
                            required>
                        <option value="">MM</option>
                        <?php for($i=1;$i<=12;$i++): ?>
                            <option value="<?php echo e(sprintf('%02d',$i)); ?>"><?php echo e(sprintf('%02d',$i)); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>-</label>
                    <select name="credit[cc_expire_year]" class="form-control" id="expYear"
                            required>
                        <option value="">YYYY</option>
                        <?php for($i=0;$i<20;$i++): ?>
                            <option value="<?php echo e(\Carbon\Carbon::now()->addYear($i)->format('Y')); ?>">
                                <?php echo e(\Carbon\Carbon::now()->addYear($i)->format('Y')); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>CVV Number*</label>
                    <input class="form-control" name="credit[ccv]" value="012" id="cvv" required>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Country*</label>
                    <select name="credit[country]" class="form-control">
                        <?php echo $__env->make('frontEnd.cart.layouts.countryList', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </select>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<?php $__env->startSection('_extra_js'); ?>
    @parent
    <?php if(payment()->hasTwoCheckout): ?>
        <script src="https://www.2checkout.com/checkout/api/2co.min.js"></script>
        <script>
            let successCallback = function (data) {
                let form = document.getElementById('checkOutForm');
                form.token.value = data.response.token.token;
                form.submit();
            };
            let errorCallback = function (data) {
                if (data.errorCode === 200) {
                    tokenRequest();
                } else {
                    alert(data.errorMsg);
                }
            };
            let tokenRequest = function () {
                let args = {
                    sellerId: "<?php echo e(payment()->twoCheckout->getAllAttr()['partner_id']); ?>",
                    publishableKey: "<?php echo e(payment()->twoCheckout->getAllAttr()['public_key']); ?>",
                    ccNo: $("#ccNo").val(),
                    cvv: $("#cvv").val(),
                    expMonth: $("#expMonth").val(),
                    expYear: $("#expYear").val()
                };
                // Make  token request
                TCO.requestToken(successCallback, errorCallback, args);
            };
            $(function () {
                // Pull in the public encryption key for our environment
                TCO.loadPubKey('sandbox');

                $('#checkOutForm').submit(function (e) {
                    if (!$(this).hasClass('paypal')) {
                        tokenRequest();
                        return false;
                    }
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>