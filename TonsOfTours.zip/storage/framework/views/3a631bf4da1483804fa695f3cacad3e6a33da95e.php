<div id="includes" class="tab-pane fade">
    <h3>Includes</h3>
    <div id="includes-group">
        <?php if(!is_null($item)): ?>
            <?php $__currentLoopData = $item->includes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $include): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row">
                    <input type="hidden" name="item[includes][<?php echo e($include->id); ?>][id]" value="<?php echo e($include->id); ?>">
                    <div class="col-md-11">
                        <div class="form-group">
                            <input class="form-control" name="item[includes][<?php echo e($include->id); ?>][txt]" value="<?php echo e($include->txt); ?>" placeholder="Text"
                                   required="">
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="form-group">
                            <a class=" btn btn-default" id="deleteRow"><i class="fa fa-fw fa-trash-o"></i></a>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endif; ?>
        
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <a class="btn btn-success" id="addIncludes"><i class="fa fa-fw fa-plus"></i>Add Includes</a>
            </div>
        </div>

    </div>

</div>
<?php $__env->startSection('Extra_Js'); ?>
    @parent
    <script>
        $("a#addIncludes").on('click', function (event) {
            event.preventDefault();
            let groupStack = $("#includes-group");
            groupStack.append('<div class="row">\n' +
                '            <div class="col-md-11">\n' +
                '                <div class="form-group">\n' +
                '                    <input class="form-control" name="item[includes][][txt]" value="" placeholder="Text" required>\n' +
                '                </div>\n' +
                '            </div>\n' +
                '            <div class="col-md-1">\n' +
                '                <div class="form-group">\n' +
                '                    <a class=" btn btn-default" id="deleteRow"><i class="fa fa-fw fa-trash-o"></i></a>\n' +
                '                </div>\n' +
                '\n' +
                '            </div>\n' +
                '        </div>');
            removeRow();
        });

        function removeRow() {
            $("a#deleteRow").on('click', function (event) {
                event.preventDefault();
                let row = $(this).closest('.row');
                row.remove();
            });
        }
    </script>
<?php $__env->stopSection(); ?>