<?php $__env->startSection('content'); ?>
<!-- welcome -->
<div class="main-box row">
    <?php $__currentLoopData = $Categories->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row blocks-row">
        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-4">
            <div class="blocks">
                <a href="<?php echo e(route('cities.show',['city'=>urlencode($Category->name),'id'=>$Category->id])); ?>" title="<?php echo e($Category->name); ?>"><img alt="" src="images/sorts/thumb/<?php echo e($Category->img); ?>" /></a>
                <h6 class="blocks-title"><a href="<?php echo e(route('cities.show',['city'=>urlencode($Category->name),'id'=>$Category->id])); ?>" title="Ras Mohamed By Boat"> <?php echo e($Category->name); ?></a></h6>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>