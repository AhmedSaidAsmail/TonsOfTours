<html>
<head>
    <style>
        @import  url('https://fonts.googleapis.com/css?family=Lato:300,400,700');

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Lato', sans-serif;
            color: #2c3e50;
        }

        .container {
            width: 100%;
            background-color: #e6e6e6;
            padding: 10px 0;
        }

        span {
            display: block;
        }

        .msg-container {
            width: 94%;
            margin: 10px auto;
            background-color: #ffffff;
            padding: 20px;
            border: 1px solid #c8c6c6;

        }

        .logo-holder {
            display: block;
            padding-bottom: 10px;
            position: relative;
            margin-bottom: 15px;
        }

        .logo-holder:after {
            position: absolute;
            top: 100%;
            left: 0;
            height: 1px;
            width: 100%;
            background-color: #c8c6c6;
            content: '';
        }

        table {
            width: 90%;
            margin: 10px auto;
            text-align: center;
            /*border: 1px solid #c8c6c6;*/
        }

        table > thead > tr > th, table > tbody > tr > td {
            border-bottom: 1px solid #c8c6c6;
            padding-top: 5px;
            padding-bottom: 5px;
        }

        h2 {
            font-style: italic;
            font-weight: 300;
            margin: 0;
            color: #e74c3c;
        }

        .customer-service {
            font-style: italic;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="msg-container">
    <span class="logo-holder">
        <img src="<?php echo e(asset('images/logo.png')); ?>">
    </span>
        Dear <?php echo e($reservation->customer->name); ?>

        <p>Thank you for choosing to book with <?php echo e(Request::getHost()); ?></p>
        <p>I am pleased to confirm receipt of your booking as follows:</p>
        <span class="details-header">YOUR BOOKING DETAILS</span>
        <table>
            <thead>
            <tr>
                <th>Tour</th>
                <th>Travellers</th>
                <th>Date</th>
                <th>Total</th>
                <th>Deposit</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $reservation->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($item->item->title); ?></td>
                    <td>
                        <?php echo e($item->st_num); ?> <?php echo e($item->st_name); ?>

                        <?php if($item->sec_num >0): ?>
                            | <?php echo e($item->sec_num); ?> <?php echo e($item->sec_name); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->date); ?></td>
                    <td><?php echo e($item->currency); ?><?php echo e(sprintf('%.2f',$item->total)); ?></td>
                    <td><?php echo e($item->currency); ?><?php echo e(sprintf('%.2f',$item->deposit)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </tbody>
        </table>
        <span>Total:<?php echo e(translate('$')); ?><?php echo e(sprintf('%.2f',$reservation->total)); ?></span>
        <span>Deposit:<?php echo e(translate('$')); ?><?php echo e(sprintf('%.2f',$reservation->deposit)); ?></span>
        <span>Transaction ID: <?php echo e($reservation->paymentId); ?></span>
        <span>Payment method: <?php echo e($reservation->payment_method); ?></span>
        <br>
        <span>You can make login using ( Email:<?php echo e($reservation->customer->email); ?> | Password:booking ) to manage your booking, if you don't have account</span>
        <br><br>
        <h2>Best Regards</h2>
        <span class="customer-service"><?php echo e(Request::getHost()); ?> Customer Service Team</span>
    </div>
</div>
</body>
</html>