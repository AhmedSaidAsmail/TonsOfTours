Hi <?php echo e($name); ?><br><br>

Thank you for contacting <?php echo e($web); ?> .  We have received your email and our Customer Service team will be responding to you soon.<br><br>

You may also refer to our Web site at <a href="<?php echo e(asset('')); ?>"><?php echo e($web); ?></a> for more information.<br><br>

Please note our working days from Monday to Friday and we regret the delay in reply over the non-working days.<br><br>

Best regards<br>
Client Care<br>
<?php echo e($web); ?><br>
Email: <?php echo e($email); ?><br>
Tel: <?php echo e($mob); ?><br>
