<?php $__env->startSection('content'); ?>
<!-- welcome -->
<div class="main-box row">
    <?php $__currentLoopData = $Items->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row blocks-row">
        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-4">
            <div class="blocks">
                <h6 class="blocks-title"><a href="show.php?id=4" title="Ras Mohamed By Boat"> <?php echo e($Item->name); ?></a></h6>
                <a href="<?php echo e(route('tour.show',['city'=>urlencode($Item->sort->name),'tour'=>urlencode($Item->name),'id'=>$Item->id])); ?>" title="<?php echo e($Item->name); ?>">
                    <img alt="" src="<?php echo e(asset('images/items/thumb/'.$Item->img)); ?>" /></a>
                <h6 class="blocks-title2"> <a href="<?php echo e(route('tour.show',['city'=>urlencode($Item->sort->name),'tour'=>urlencode($Item->name),'id'=>$Item->id])); ?>"><?php echo e((isset($Item->price->st_price)?$Item->price->st_price:'00')); ?> <?php echo e(Vars::getVar("currency")); ?></a> </h6>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>