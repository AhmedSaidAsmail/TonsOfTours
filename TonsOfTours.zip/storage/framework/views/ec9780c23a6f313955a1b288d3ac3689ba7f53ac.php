<?php $__env->startSection('meta_tags'); ?>
<?php $meta = App\MyModels\Admin\Topic::where('name', 'Home')->first() ?>
<meta name="keywords" content="<?php echo e($meta->keywords); ?>" />
<meta name="description" content="<?php echo e($meta->description); ?>" />
<title><?php echo e($meta->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- welcome -->
<div class="box-welcome row">
    <img src="images/welcome.png" />
    <div class="line"> </div>

    <?php if($meta->Topics_text): ?>
    <?php echo $meta->Topics_text->txt; ?>

    <?php endif; ?>
    <div class="decorative"></div>
</div>
<div class="main-box row">
    <?php $__currentLoopData = $Categories->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="row blocks-row">
        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-4">
            <div class="blocks">
                <a href="<?php echo e(route('cities.show',['city'=>urlencode($Category->name),'id'=>$Category->id])); ?>" title="<?php echo e($Category->name); ?>"><img alt="" src="images/sorts/thumb/<?php echo e($Category->img); ?>" /></a>
                <h6 class="blocks-title"><a href="<?php echo e(route('cities.show',['city'=>urlencode($Category->name),'id'=>$Category->id])); ?>" title="Ras Mohamed By Boat"> <?php echo e($Category->name); ?></a></h6>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>