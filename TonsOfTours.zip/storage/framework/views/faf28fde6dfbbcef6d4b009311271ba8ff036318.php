<?php $__env->startSection('meta_tags'); ?>
    <meta name="keywords" content="<?php echo e($category->keywords); ?>"/>
    <meta name="description" content="<?php echo e($category->description); ?>"/>
    <title><?php echo e($category->title); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <img class="aspect-img" src="<?php echo e(asset('images/categories/'.$category->img)); ?>"
             alt="<?php echo e($category->title); ?>">
        <div class="insider-header-contains">
            <div class="container">
                <ul class="list-inline dir">
                    <li><?php echo e(translate('WHERE_TO_GO')); ?></li>
                    <?php
                    $mainCategory = $category->mainCategory;
                    ?>
                    <li>
                        <a href="<?php echo e(route('home.mainCategory.show',['name'=>urlencodeLink($mainCategory->name),'id'=>$mainCategory->id])); ?>">
                            <?php echo e($mainCategory->title); ?>

                        </a>
                    </li>
                    <li><?php echo e($category->title); ?></li>
                </ul>
                <h1><?php echo e($category->title); ?></h1>
            </div>
        </div>

    </div>
    <?php echo $__env->make('frontEnd.layouts._headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <h1 class="main-title"><?php echo e($category->title); ?></h1>
            <?php $__currentLoopData = $category->items->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="row items-container">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <?php
                        $link = route('home.item.show', [
                            'category' => urlencodeLink($item->category->name),
                            'name' => urlencodeLink($item->name),
                            'id' => $item->id]);
                        ?>
                        <div class="col-md-4">
                            <div class="item-container">
                                <?php if($item->offer): ?>
                                    <div class="hot-offers-label"></div>
                                <?php endif; ?>

                                <div class="row item-container-footer">
                                    <div class="col-md-6 col-xs-6 col-sm-6 item-footer-price">
                                        <?php if(isset($item->price)): ?>
                                            <?php echo e(sprintf('%.2f',$item->cheapestPrise()->st_price)); ?>

                                        <?php endif; ?>
                                        <span><?php echo e(payment()->currency_symbol); ?></span>
                                    </div>
                                    <div class="col-md-6 col-xs-6 col-sm-6 item-footer-basket">
                                        <a href="<?php echo e($link); ?>">
                                            <?php echo e(translate('Add_to_basket')); ?> <i class="fa fa-cart-plus"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="item-container-img">
                                    <a href="<?php echo e($link); ?>">
                                        <img src="<?php echo e(asset('images/items/thumbMd/'.$item->img)); ?>" alt="<?php echo e($item->title); ?>">
                                    </a>
                                </div>
                                <div class="item-container-text">
                                    <h2><?php echo e($item->name); ?></h2>
                                    <span>
                                        <?php echo e(str_limit($item->intro,90,'...')); ?>

                                        <a href="<?php echo e($link); ?>">Read More</a>
                                    </span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    </div>
    <?php echo $__env->make('frontEnd.layouts._freeCancellationLayer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="container">
            <div class="more-ideas">
                <h1><?php echo e(translate('Find_More_Travel_Ideas')); ?></h1>
                <ul class="list-inline text-center">
                    <?php $number = 1; ?>
                    <?php $__currentLoopData = $otherCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('home.category.show',['city'=>urlencodeLink($otherCategory->name),'id'=>$otherCategory->id])); ?>"
                               class="label-container">
                                <span class="label-number"><?php echo e($number); ?></span>
                                <span class="label-title"><?php echo e($otherCategory->name); ?></span>
                            </a>
                        </li>
                        <?php $number++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>