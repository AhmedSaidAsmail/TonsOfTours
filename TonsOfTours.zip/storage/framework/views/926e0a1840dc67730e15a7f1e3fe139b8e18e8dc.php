<?php $__env->startSection('meta_tags'); ?>
<title><?php echo e($category->title); ?></title>
<meta name="keywords" content="<?php echo e($category->keywords); ?>">
<meta name="description" content="<?php echo e($category->description); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
<?php echo $__env->make('Web.nav-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row exc-container">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="row" style="margin-bottom: 20px; border: 1px outset #6a97ae; border-radius: 10px; overflow: hidden;">
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-active">
                        <i class="fa fa-cart-plus"></i> <?php echo e(Vars::getVar("Add_to_Cart")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <i class="fa fa-users" aria-hidden="true"></i> <?php echo e(Vars::getVar("Review_Orders")); ?>

                        <div class="checkout-refrences-arrow"></div>
                        <div class="checkout-refrences-arrow-bg"></div>
                    </div>
                    <div class="col-md-4 col-xs-4 checkout-refrences checkout-refrences-inactive">
                        <i class="fa fa-lock"></i> <?php echo e(Vars::getVar("Secure_checkout")); ?>

                    </div>
                </div>
                <!-- end directory -->
                <div class="row" >
                    <div class="col-md-12 exc-item-img-title">
                        <h3><span class="glyphicon glyphicon-briefcase"></span> <?php echo e($category->title); ?></h3>
                    </div>

                </div>
                <div class="row">
                    <div class="col-md-12 exc-item-img">
                        <img src="<?php echo e(asset('images/sorts/'.$category->img)); ?>" alt="">
                    </div>
                </div>

                <div class="row exc-items-conatiner">
                    <?php $__currentLoopData = $category->items->where('status',"=",1)->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunks): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="row welcome-items">
                        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <div class="col-md-6" >

                            <div class="welcome-item">
                                <?php if($item->offer): ?>
                                <div class="hot-offers"></div>
                                <?php endif; ?>

                                <div class="thumb-one row">
                                    <div class="col-md-6">
                                        <?php if(isset($item->price)): ?>
                                        <?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                        <?php endif; ?>
                                        <span class="price-currency-label"><?php echo e(Vars::getVar("$")); ?></span></div>
                                    <div class="col-md-6" style=" text-align: right;">
                                        <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>" style="color:inherit; text-decoration: none;">
                                            <?php echo e(Vars::getVar('Add_to_basket')); ?> <i class="fa fa-cart-plus" style="color: #67ab34;" ></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="welcome-item-img-container">
                                    <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">
                                        <img src="<?php echo e(asset('images/items/'.$item->img)); ?>"  alt="<?php echo e($item->title); ?>" style="width: 100%;">
                                    </a>
                                </div>

                                <div class="welcome-item-txt-container">
                                    <div class="welcome-img-border">
                                        <span class="glyphicon glyphicon-triangle-top"></span>
                                    </div>
                                    <h2><?php echo e($item->name); ?></h2>
                                    <?php
                                    echo substr($item->intro, 0, 90);
                                    ?>

                                    ...<a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>">Read More</a>

                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>


                </div>

            </div>
            <div class="col-md-4">
                <?php echo $__env->make('Web.Layouts.TrnasferForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                <div class="row">
                    <div class="col-md-12 youtube-holder">
                        <iframe id="youtube"  height="315" src="https://www.youtube.com/embed/jnfwoGw3fnU" frameborder="0" allowfullscreen></iframe>
                    </div>


                </div>

                <div class="row" style="padding: 7px;">
                    <div class="col-md-12" style="border: 1px solid #e5e5e5; margin-top: 15px; background: #FFF; border-radius: 5px;">
                        <h1 class="bannser-ref-header"><?php echo e($category->title); ?></h1>
                        <ul class="banner-ref-list">
                            <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <li>
                                <!-- <a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>"><?php echo e($item->title); ?></a> -->

                                <div class="row">
                                    <div class="col-md-3"  style="padding: 0px;">
                                        <img src="<?php echo e(asset('images/items/thumb/'.$item->img)); ?>" alt="" style="width: 100%;">
                                    </div>
                                    <div class="col-md-9 text-right">
                                        <div class="row banner-ref-list-title"><a href="<?php echo e(route('tour.show',['city'=>urlencode($category->name),'tour'=>urlencode($item->name),'id'=>$item->id])); ?>" title="<?php echo e($item->title); ?>">
                                                <?php echo e(substr($item->title,0,25)); ?>

                                            </a></div>
                                        <div class="row">
                                            <?php echo e(Vars::getVar('from')); ?>

                                            <span class="banner-ref-list-price">£<?php if(isset($item->price)): ?><?php echo e(sprintf('%.2f',$item->price->st_price)); ?>

                                                <?php endif; ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-10">
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("More_Things_to_Do_in_Sharm_el_Sheikh")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Seccategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><span><a href="<?php echo e(route('cities.show',['city'=>urlencode($Seccategory->name),'id'=>$Seccategory->id])); ?>"><?php echo e($Seccategory->title); ?></a></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
            <div class="row more-attractions">
                <h3><?php echo e(Vars::getVar("Top_Sharm_el_Sheikh_Attractions")); ?></h3>
                <ul class="list-inline">
                    <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php $__currentLoopData = $LinkCategory->items->where('recommended',"=",1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $LinkItems): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li><span><a href="<?php echo e(route('tour.show',['city'=>urlencode($LinkCategory->name),'tour'=>urlencode($LinkItems->name),'id'=>$LinkItems->id])); ?>"><?php echo e($LinkItems->title); ?></a></span></li>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_css'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('adminlte/plugins/select2/select2.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('_extra_js'); ?>
<script src="<?php echo e(asset('adminlte/plugins/select2/select2.full.min.js')); ?>"></script>
<!-- date Range -->
<script src="<?php echo e(asset('adminlte/plugins/daterangepicker/daterangepicker.js')); ?>"></script>
<script>
$(function() {
//Initialize Select2 Elements
    $(".select2").select2();
    $('#reservation').daterangepicker({
        startDate: new Date(),
        minDate: new Date()

    });


});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Web.Layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>