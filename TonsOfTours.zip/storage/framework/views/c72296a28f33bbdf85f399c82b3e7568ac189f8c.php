<div id="includes" class="tab-pane fade">
    <h3>Includes</h3>
    
    <textarea class="full-text" style="width: 100%;" name="includes" required><?php echo e(getValue('includes',$item,'inclusion')); ?></textarea>
</div>