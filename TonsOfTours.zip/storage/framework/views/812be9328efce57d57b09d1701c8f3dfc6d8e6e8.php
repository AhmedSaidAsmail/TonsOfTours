
<!-- header menu -->
<div class="row top-header">
    <div class="container">
        <nav class="navbar" id="header-nav" style=" min-height: 0px;">
            <div class="container-fluid headerLinks">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="<?php echo e(route('home')); ?>"><span class="glyphicon glyphicon-home"></span><?php echo e(Vars::getVar("Home")); ?></a></li>
                    <li><a href="<?php echo e(route('cart')); ?>"><span class="glyphicon glyphicon-shopping-cart"></span>Cart <span  id="shoping-cart-header">(
                                <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?>

                            )</span></a></li>
                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><a href="<?php echo e(route('topics.show',['topicsName'=>urlencodeLink($top->name)])); ?>">
                            <?php if(!is_null($top->icon)): ?>
                            <span class="glyphicon <?php echo e($top->icon); ?>"></span>
                            <?php endif; ?>
                            <?php echo e($top->top_link); ?> </a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    
                </ul>


            </div>
        </nav>
    </div>
</div>
<!-- end header menu -->
<!-- navigator Menu -->
<div class="row main-nav-normal animated" id="main-nav">
    <div class="nav-attention">
        <i class="fa fa-asterisk" aria-hidden="true"></i> <?php echo e(Vars::getVar('book_online_and_pay_when_come_Egypt')); ?>

    </div>
    <div class="container" id="responsive-nav" >
        <div class="responsive-menu-header">
            <div class="row">
                <div class="col-sm-2 col-xs-2 responsive-menu-icon-cover">
                    <div class="responsive-menu-icon">
                        <div class="hamburger"></div>
                    </div>

                </div>
                <div class="col-sm-7 col-xs-7 responsive-menu-logo-cover">
                    <div class="responsive-menu-logo"></div>
                </div>
                <div class="col-sm-3 col-xs-3 responsive-menu-cart">
                    <a href="<?php echo e(route('cart')); ?>">
                        <span class="glyphicon glyphicon-shopping-cart"></span>
                        <span class="responsive-menu-cart-no">
                            <?php echo e(Session::has('cart')?Session::get('cart')->totalQty:0); ?>

                        </span></a>
                </div>
            </div>

        </div>
        <div class="row responsive-menu-side">
            <div class="col-md-2 logo-conatiner col-sm-8 col-xs-8">
                <span class="logo-header logo-header-position"></span>
            </div>
            <div class="col-sm-12 col-xs-12 responsive-menu-title">
                Main Menu
            </div>
            <div class="col-md-10 col-sm-12 col-xs-12 responsive-menu-conatiner">
                <ul id="main-nav-main" style="position: relative;">
                    <?php $__currentLoopData = App\MyModels\Admin\Basicsort::where('home','=','1')->limit(4)->orderBy('arrangement','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sortMenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li>
                        <a href="#" class="normal-link"><i class="fa <?php echo e($sortMenu->icon); ?>"></i> <?php echo e($sortMenu->title); ?>

                        <i class="fa fa-caret-up link-arraow"></i>
                        </a>
                        <?php if(count($sortMenu->sorts)>0): ?>
                        <div class="responsive-menu-arrow">
                            <i class="fa fa-angle-down"></i>
                        </div>
                        
                        <div class=" row submenu">
                            <?php $__currentLoopData = $sortMenu->sorts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="row">
                                <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-4">
                                    <h2><a href="<?php echo e(route('cities.show',['city'=>urlencodeLink($category->name),'id'=>$category->id])); ?>" style="color:#5e5e5e;"><?php echo e($category->name); ?></a></h2>

                                    <?php if(count($category->items)>0): ?>
                                    <ul>
                                        <?php $__currentLoopData = $category->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemmenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <li><a href="<?php echo e(route('tour.show',['city'=>urlencodeLink($category->name),'tour'=>urlencodeLink($itemmenu->name),'id'=>$itemmenu->id])); ?>" title="<?php echo e($itemmenu->title); ?>"><?php echo e(substr($itemmenu->name,0,30)); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </ul>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <!-- start navigator menu -->

                    <li><a href="<?php echo e(route('transfersShow')); ?>" class="additional-link"><i class="fa fa-car"></i> <?php echo e(Vars::getVar('Airport Transfers')); ?></a></li>
                    <li><a href="<?php echo e(route('hotDeals')); ?>" class="additional-link"><i class="fa fa-heart"></i> <?php echo e(Vars::getVar('Hot_Offers')); ?></a></li>
                    <li class="responsive-menu-topics"><a href="<?php echo e(route('home')); ?>" class="normal-link"><span class="glyphicon glyphicon-home"></span><?php echo e(Vars::getVar("Home")); ?></a></li>
                    <?php $__currentLoopData = App\MyModels\Admin\Topic::where('top',1)->orderBy('arrangement','asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li class="responsive-menu-topics"><a href="<?php echo e(route('topics.show',['topicsName'=>urlencodeLink($top->name)])); ?>" class="normal-link">
                            <?php if(!is_null($top->icon)): ?>
                            <span class="glyphicon <?php echo e($top->icon); ?>"></span>
                            <?php endif; ?>
                            <?php echo e($top->top_link); ?> </a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                </ul>
            </div>
        </div>

    </div>
</div>
<!-- end navigator menu -->