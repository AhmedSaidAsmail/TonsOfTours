<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Settings')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <div class="row customer-setting-form">
                <div class="col-md-3 setting-links-holder">
                    <ul class="list-group list-group-sp">
                        <li class="list-group-item">
                            <a href="<?php echo e(route('customer.booking')); ?>">
                                <i class="fas fa-plane-departure"></i> <?php echo e(translate('Bookings')); ?>

                            </a>
                        </li>
                        <li class="list-group-item active">
                            <a href="<?php echo e(route('customer.setting')); ?>">
                                <i class="fa fa-user"></i> <?php echo e(translate('Profile')); ?>

                            </a>
                        </li>
                        <li class="list-group-item ">
                            <a href="<?php echo e(route('customer.password')); ?>">
                                <i class="fa fa-lock"></i> <?php echo e(translate('Password')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-9 customer-setting-details">
                    <h1><?php echo e(translate('Personal_information')); ?></h1>
                    <form action="<?php echo e(route('customer.setting')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="PUT">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Name</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <input class="form-control" name="name" value="<?php echo e($customer->name); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-at"></i>
                                        </div>
                                        <input class="form-control" name="email" value="<?php echo e($customer->email); ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mobile</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-mobile-alt"></i>
                                        </div>
                                        <input class="form-control" name="information[phone]"
                                               value="<?php echo e($customer->information->phone); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-location-arrow"></i>
                                        </div>
                                        <input class="form-control" name="information[address]"
                                               value="<?php echo e($customer->information->address); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>City</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-city"></i>
                                        </div>
                                        <input class="form-control" name="information[city]"
                                               value="<?php echo e($customer->information->city); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Country</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">
                                            <i class="fas fa-flag"></i>
                                        </div>
                                        <input class="form-control" name="information[country]"
                                               value="<?php echo e($customer->information->country); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-success btn-block">
                                    <i class="fas fa-save"></i> Update Information
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>