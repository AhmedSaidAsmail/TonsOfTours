<?php $__env->startSection('meta_tags'); ?>
    <title><?php echo e(translate('Shopping_Cart')); ?> | <?php echo e(Request::getHost()); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-nav'); ?>
    <div class="row insider-header-container-sp">
        <?php echo $__env->make('frontEnd.layouts._mainNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="container">
            <?php if($cart->quantity > 0): ?>
                <h1 class="cart-header">
                    <?php echo e(translate('Hooray,_you’ve_successfully_added')); ?> <?php echo e($cart->quantity); ?> <?php echo e(translate('item_to_your_cart.')); ?>

                </h1>
                <h2 class="cart-header"><?php echo e(translate('Only_2_more_steps_to_go!')); ?></h2>
                <span class="cart-cookie-notify">
                <i class="fa fa-clock-o"></i>
                    <?php echo e(translate('Once_you_add_an_activity_to_your_cart,_we_will_save_your_spot_for_60_minutes.')); ?>

            </span>
                <div class="row cart-items-holder">
                    <div class="col-md-8">
                        <?php $__currentLoopData = $cart->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php
                            $model = getItem($item->item_id);
                            ?>
                            <div class="cart-item">
                                <div class="row cart-item-details">
                                    <div class="cart-item-remove">
                                        <a href="<?php echo e(route('cart.item.remove',$item->removeParameters())); ?>">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    </div>
                                    <div class="cart-item-price">
                                        <sub>
                                            <span>Total:</span> <?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->total)); ?>

                                        </sub>
                                        <sub>
                                            <?php if($item->deposit>0): ?>
                                                <span>Deposit Due:</span> <?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->deposit)); ?>

                                            <?php else: ?>
                                                <span>No Deposit</span>
                                            <?php endif; ?>
                                        </sub>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="item-card-img">
                                            <img src="<?php echo e(asset('images/items/thumbSm/'.$model->img)); ?>"
                                                 class="aspect-img" alt="<?php echo e($model->title); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-10 cart-details">
                                        <h2><?php echo e($model->title); ?></h2>
                                        <span><?php echo e($item->date); ?></span>
                                        <?php if($item->st_num): ?>
                                            <span>
                                            <label class="numbers"><?php echo e($item->st_num); ?></label>
                                                <?php echo e($item->st_name); ?> ×
                                            <label class="numbers"><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->st_price)); ?></label>
                                                <?php echo e(payment()->currency); ?>

                                        </span>
                                        <?php endif; ?>
                                        <?php if($item->sec_num): ?>
                                            <span>
                                            <label class="numbers"><?php echo e($item->sec_num); ?></label>
                                                <?php echo e($item->sec_name); ?> ×
                                            <label class="numbers"><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$item->sec_price)); ?></label>
                                                <?php echo e(payment()->currency); ?>

                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="cart-item-footer row">
                                    <div class="col-md-12">
                                        <?php echo e(translate('Book_without_regrets!')); ?>

                                        <label><?php echo e(translate('Cancel_your_activity_for_free_any_time_up_until')); ?>

                                            <?php echo e(\Carbon\Carbon::parse($item->date)->subDay(2)->format('l, M d, Y')); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <div class="col-md-4">
                        <div class="cart-all-total">
                        <span class="cart-header-total">
                            Total (<?php echo e($cart->quantity); ?> items):
                            <label><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$cart->total)); ?></label>
                        </span>
                            <span class="cart-header-total">
                            Total Deposit:
                            <label><?php echo e(payment()->currency_symbol); ?><?php echo e(sprintf('%.2f',$cart->deposit)); ?></label>
                        </span>
                            <span>No additional fees.</span>
                            <a href="<?php echo e(route('cart.checkout')); ?>"
                               class="btn btn-info btn-block">Checkout</a>
                            <?php if(!Auth::guard('customer')->check()): ?>
                                <div class="cart-all-bottom">
                                    <a href="<?php echo e(route('customer.register')); ?>">Create an account</a>
                                    or
                                    <a href="#" id="login">log in</a>
                                    <span>for faster checkout.</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-cart">
                    <h1>Your cart is empty.</h1>
                    <span>The world is waiting for you. Fill up on amazing things to do in egypt.</span>
                    <a class="btn btn-primary btn-block" href="<?php echo e(route('home')); ?>">
                        Continue Shopping
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>