<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Directory&Header -->
        <section class="content-header">
            <h1> Reservations
                <small>Archive tables</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
                <li><a href="#">Reservations</a></li>
            </ol>
        </section>
        <!-- end Directory&Header -->
        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- box -->

                    <!-- end box 1 -->
                    <!-- /.box -->
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Reservations Archive Data With Full Features</h3>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body">
                            <table id="dataTable" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Tours</th>
                                    <th>Total</th>
                                    <th>Deposit</th>
                                    <th>Approval</th>
                                    <th>#Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php echo e(date('M d, Y',strtotime($reservation->date))); ?></td>
                                        <td><?php echo e($reservation->customer->name); ?></td>
                                        <td><?php echo e($reservation->customer->email); ?></td>
                                        <td><?php echo e($reservation->items->count()); ?></td>
                                        <td><?php echo e($reservation->total); ?></td>
                                        <td><?php echo e($reservation->deposit); ?></td>
                                        <td>
                                            <i class="fa fa-circle <?php echo ($reservation->approval)? 'text-green':'text-gray'; ?>"></i>
                                        </td>
                                        <td>
                                            <ul class="list-inline">
                                                <li>
                                                    <a href="<?php echo e(route('reservation.show',['id'=>$reservation->id])); ?>">
                                                        <i class="fa fa-search fa-lg text-primary"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <th>Date</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Tours</th>
                                    <th>Total</th>
                                    <th>Deposit</th>
                                    <th>Approval</th>
                                    <th>#Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
    <script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#dataTable").DataTable({
                "order": [[0, "desc"]]
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>