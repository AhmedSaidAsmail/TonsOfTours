<?php $__env->startSection('title','Items Panel'); ?>
<?php $__env->startSection('Extra_Css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1> Items
                <small>Items tables</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> C-Panel</a></li>
                <li><a href="#">Items</a></li>
            </ol>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <!-- box -->
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="form-group">
                                <a href="<?php echo e(route('item.create')); ?>" class="btn btn-warning btn-block">
                                    <i class="fa fa-plus-square fa-lg"></i> Add New Items
                                </a>
                            </div>
                            
                            <?php if(Session::has('alert')): ?>
                                <div class="alert <?php echo e(Session('alertType')); ?> alert-dismissible">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">
                                        &times;
                                    </button>
                                    <h4><i class="icon fa fa-ban"></i> <?php echo e(Session('alert')); ?> </h4>
                                    <?php if(Session::has('alertDetails')): ?>
                                        ..<a href="#" id="errorDetails">Details</a>
                                        <p id="ErrorMsgDetails"><?php echo e(Session('alertDetails')); ?></p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                        </div>

                    </div>
                    <div class="box">
                        <div class="box-header">
                            <h3 class="box-title">Categories Data With Full Features</h3>
                        </div>
                        <div class="box-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th>Category</th>
                                    <th>Item</th>
                                    <th>Status</th>
                                    <th>Recommended</th>
                                    <th>Visitors</th>
                                    <th>#Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php echo e($item->category->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->name); ?>

                                        </td>
                                        <td>
                                            <i class="fa fa-circle text-<?php echo $item->status?"green":"gray"; ?>"></i>
                                        </td>
                                        <td>
                                            <i class="fa fa-circle text-<?php echo $item->recommended?"green":"gray"; ?>"></i>
                                        </td>
                                        <td>
                                            <?php echo e($item->visitors()->count()); ?>

                                        </td>
                                        <td>
                                            <form method="post" action="<?php echo e(route('item.destroy',['id'=>$item->id])); ?>"
                                                  id="itemDelete">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="DELETE">
                                            </form>
                                            <ul class="list-inline text-center">
                                                <li>
                                                    <a href="<?php echo e(route('item.edit',['id'=>$item->id])); ?>">
                                                        <i class="fa fa-pencil-square fa-lg text-success"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <button class="remove-button" form="itemDelete">
                                                        <i class="fa fa-trash-o fa-lg text-danger"></i>
                                                    </button>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>

                                <tfoot>
                                <tr>
                                    <th>Category</th>
                                    <th>Item</th>
                                    <th>Status</th>
                                    <th>Recommended</th>
                                    <th>Visitors</th>
                                    <th>#Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Extra_Js'); ?>
    <script src="<?php echo e(asset('js/admin/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin_resources/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
    <script>
        $(function () {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.Layouts._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>