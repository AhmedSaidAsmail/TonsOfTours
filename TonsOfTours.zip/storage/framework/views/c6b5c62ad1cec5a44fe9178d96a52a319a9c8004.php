<div id="excludes" class="tab-pane fade">
    <h3>Excludes</h3>

    <textarea class="full-text" style="width: 100%;" name="excludes" required><?php echo e(getValue('excludes',$item,'exclusion')); ?></textarea>
</div>