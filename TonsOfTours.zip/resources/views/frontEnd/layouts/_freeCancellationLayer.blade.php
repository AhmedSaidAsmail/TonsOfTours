<div class="cancellation-container">
    <i class="far fa-clock"></i>
    <h2>Free cancellation</h2>
    <span>
        You'll receive a full refund if you cancel at least 24 hours in advance of most experiences.
    </span>
</div>