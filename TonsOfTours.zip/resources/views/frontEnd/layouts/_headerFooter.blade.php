<div class="welcome-footer">
    <div class="container">
        <div class="row welcome-footer-slogans">
            <div class="col-md-3 col-xs-3">
                <i class="fas fa-gift"></i>
                <h2>The best selection</h2>
                <span class="slogan-text">More than 1000 things to do</span>
            </div>
            <div class="col-md-3 col-xs-3">
                <span class="fa-stack">
                    <i class="fa fa-certificate fa-stack-2x"></i>
                    <i class="fa fa-usd fa-inverse fa-stack-1x"></i>
                </span>
                <h2>The lowest prices</h2>
                <span class="slogan-text">We guarantee it!</span>
            </div>
            <div class="col-md-3 col-xs-3">
                <i class="fas fa-shopping-cart"></i>
                <h2>Fast & easy booking</h2>
                <span class="slogan-text">Book online to lock in your tickets</span>
            </div>
            <div class="col-md-3 col-xs-3">
                <i class="fas fa-user-clock"></i>
                <h2>Customer service</h2>
                <span class="slogan-text">English speaking customer service representatives!!</span>
            </div>
        </div>
    </div>
</div>